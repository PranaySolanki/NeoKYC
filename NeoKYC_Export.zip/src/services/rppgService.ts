import { NativeModules, Platform } from 'react-native';

const { RppgModule } = NativeModules;

export type LivenessVerdict =
  | 'REAL_FACE_VERIFIED'
  | 'SPOOF_DETECTED'
  | 'VERIFICATION_FAILED'
  | 'INCONCLUSIVE';

export type VerdictTier = 'VERIFIED' | 'RETRY_REQUIRED' | 'INCONCLUSIVE' | 'FAILED';

export type RppgStatus =
  | 'CONFIRMED_PULSE'
  | 'INCONCLUSIVE_WEAK_SIGNAL'
  | 'INCONCLUSIVE_MOTION'
  | 'INCONCLUSIVE_NO_FACE'
  | 'INCONCLUSIVE_TOO_SHORT'
  | 'RETRY_REQUIRED'
  | 'FAILED'
  | 'ERROR';

export type SignalQualityTier = 'HIGH' | 'MODERATE' | 'LOW' | 'UNRELIABLE';

export type ChallengeType =
  | 'LOOK_CENTER'
  | 'BLINK'
  | 'SMILE'
  | 'TURN_LEFT'
  | 'TURN_RIGHT'
  | 'TILT_UP';

export interface LivenessChallenge {
  id: string;
  type: ChallengeType;
  instruction: string;
  tip?: string;
  startTimeSec: number;
  endTimeSec: number;
}

export interface ChallengeVerificationResult {
  id: string;
  type: string;
  instruction: string;
  verified: boolean;
  confidence: number;
  detail: string;
}

export interface ProcessingMetrics {
  totalDurationMs: number;
  frameExtractionMs: number;
  landmarkDetectionMs: number;
  skinExtractionMs: number;
  challengeDetectionMs: number;
  dspMs: number;
  fpsSampled: number;
}

export interface RppgResult {
  success: boolean;
  verdict: LivenessVerdict;
  verdictTitle: string;
  verdictDescription: string;
  spoofReason?: string;
  verdictTier: VerdictTier;
  status: RppgStatus;
  estimatedBpm: number;
  signalQuality: SignalQualityTier;
  usableFrames: number;
  totalFrames: number;
  faceRatio: number;
  durationSeconds: number;
  snrDb: number;
  peakPowerFraction: number;
  isLikelyLiveness: boolean;
  message: string;
  spatialCoherence?: number;
  freqDiscrepancyBpm?: number;
  isDeepfakeSuspect?: boolean;
  isScreenReplaySuspect?: boolean;
  // Guided Challenge Extensions
  challenges?: ChallengeVerificationResult[];
  challengesPassed?: number;
  challengesTotal?: number;
  challengeLivenessPass?: boolean;
  processingMetrics?: ProcessingMetrics;
}

class RppgService {
  /**
   * Checks whether the native Android rPPG module is available in this runtime.
   */
  isAvailable(): boolean {
    return Platform.OS === 'android' && Boolean(RppgModule && (RppgModule.processVideo || RppgModule.processVideoWithChallenges));
  }

  /**
   * Processes a locally recorded video file via on-device MediaPipe & POS rPPG pipeline.
   * Runs completely offline with no network or server dependencies.
   *
   * @param videoUri Local file:// or content:// URI of the recorded video
   * @param challenges Optional list of guided challenges scheduled during recording
   */
  async processVideo(
    videoUri: string,
    challenges?: LivenessChallenge[]
  ): Promise<RppgResult> {
    if (!this.isAvailable()) {
      return {
        success: false,
        verdict: 'VERIFICATION_FAILED',
        verdictTitle: 'VERIFICATION FAILED — TRY AGAIN',
        verdictDescription: 'Native processing module is only available on Android native builds.',
        verdictTier: 'RETRY_REQUIRED',
        status: 'ERROR',
        estimatedBpm: 0,
        signalQuality: 'UNRELIABLE',
        usableFrames: 0,
        totalFrames: 0,
        faceRatio: 0,
        durationSeconds: 0,
        snrDb: 0,
        peakPowerFraction: 0,
        isLikelyLiveness: false,
        message: 'Native rPPG module is only available on Android native builds.',
      };
    }

    try {
      let result: RppgResult;
      if (challenges && challenges.length > 0 && RppgModule.processVideoWithChallenges) {
        const jsonChallenges = JSON.stringify(challenges);
        result = await RppgModule.processVideoWithChallenges(videoUri, jsonChallenges);
      } else {
        result = await RppgModule.processVideo(videoUri);
      }

      // Ensure verdict is assigned even if older native build is running
      if (!result.verdict) {
        if (result.isDeepfakeSuspect || result.isScreenReplaySuspect || result.spoofReason) {
          result.verdict = 'SPOOF_DETECTED';
          result.verdictTitle = 'SPOOF / FAKE FACE DETECTED';
          result.verdictDescription = 'Presentation attack detected. Live physical face required.';
        } else if ((result.challengeLivenessPass || result.status === 'CONFIRMED_PULSE') && result.faceRatio >= 0.45) {
          result.verdict = 'REAL_FACE_VERIFIED';
          result.verdictTitle = 'REAL FACE VERIFIED';
          result.verdictDescription = 'Live human face verified through confirmed biological pulse and physical presence.';
        } else if (result.faceRatio < 0.40) {
          result.verdict = 'VERIFICATION_FAILED';
          result.verdictTitle = 'VERIFICATION FAILED — TRY AGAIN';
          result.verdictDescription = 'Face tracking was lost or unclear. Please center your face in good lighting.';
        } else {
          result.verdict = 'INCONCLUSIVE';
          result.verdictTitle = 'INCONCLUSIVE — TRY AGAIN';
          result.verdictDescription = 'Signals were inconclusive under ambient conditions. Please hold steady in good natural lighting and try again.';
        }
      }

      return result;
    } catch (error: any) {
      return {
        success: false,
        verdict: 'VERIFICATION_FAILED',
        verdictTitle: 'VERIFICATION FAILED — TRY AGAIN',
        verdictDescription: error?.message || 'Processing failed. Please try again.',
        verdictTier: 'RETRY_REQUIRED',
        status: 'ERROR',
        estimatedBpm: 0,
        signalQuality: 'UNRELIABLE',
        usableFrames: 0,
        totalFrames: 0,
        faceRatio: 0,
        durationSeconds: 0,
        snrDb: 0,
        peakPowerFraction: 0,
        isLikelyLiveness: false,
        message: error?.message || 'Unknown native processing failure',
      };
    }
  }

  /**
   * Safely deletes the temporary video file from local app cache.
   * Protects user privacy by ensuring biometric video recordings do not persist.
   */
  async deleteVideoFile(videoUri: string): Promise<boolean> {
    if (!this.isAvailable()) return false;
    try {
      return await RppgModule.deleteVideoFile(videoUri);
    } catch {
      return false;
    }
  }
}

export const rppgService = new RppgService();
