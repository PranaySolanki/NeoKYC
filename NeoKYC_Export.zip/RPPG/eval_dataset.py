import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from rppg import process_video

paths = [
    r"C:\Users\Admin\.cache\huggingface\hub\datasets--AxonData--Display_replay_attacks\snapshots\f5560f659e185ded62c2f09ff502426b0588406e\Axon Labs Replay Display sample\Screen\20240823_194131.mp4",
    r"C:\Users\Admin\.cache\huggingface\hub\datasets--AxonData--Display_replay_attacks\snapshots\f5560f659e185ded62c2f09ff502426b0588406e\Axon Labs Replay Display sample\Screen\20240823_194241.mp4",
    r"C:\Users\Admin\.cache\huggingface\hub\datasets--AxonData--Display_replay_attacks\snapshots\f5560f659e185ded62c2f09ff502426b0588406e\Axon Labs Replay Display sample\Screen\IMG_5915.MOV",
    r"C:\Users\Admin\.cache\huggingface\hub\datasets--AxonData--Display_replay_attacks\snapshots\f5560f659e185ded62c2f09ff502426b0588406e\Axon Labs Replay Display sample\Screen\IMG_5987.MOV",
    r"C:\Users\Admin\.cache\huggingface\hub\datasets--AxonData--Display_replay_attacks\snapshots\f5560f659e185ded62c2f09ff502426b0588406e\Axon Labs Replay Display sample\Screen\VID_20240823_171603.mp4",
]

print("=== EVALUATION ON AXONDATA DISPLAY REPLAY ATTACKS ===")
results = []
for p in paths:
    name = os.path.basename(p)
    print(f"\n--- Processing: {name} ---")
    try:
        res = process_video(p, save_plot=None, show_plot=False, log_file=None)
        results.append({
            "name": name,
            "duration": res["duration"],
            "face_ratio": res["face_ratio"],
            "quality": res["quality_rating"],
            "verdict": res["liveness_verdict"],
            "is_real": res["is_real"],
            "is_spoof": res["is_spoof"],
            "spoof_type": res["spoof_type"],
            "mean_correlation": res["mean_correlation"],
            "mean_coherence": res["mean_coherence"],
            "bpm": res["bpm"],
            "peak_fraction": res["peak_fraction"],
            "snr_db": res["snr_db"],
            "max_gap_sec": res["max_gap_sec"],
            "screen_cues": res.get("screen_cues"),
        })
    except Exception as e:
        print(f"FAILED on {name}: {e}")
        results.append({
            "name": name,
            "error": str(e)
        })

print("\n" + "=" * 80)
print("SUMMARY TABLE (MEASURED RESULTS):")
print("=" * 80)
for r in results:
    if "error" in r:
        print(f"{r['name']}: ERROR - {r['error']}")
    else:
        sc = r.get("screen_cues") or {}
        reasons = "; ".join(sc.get("reasons", []))
        print(f"{r['name']}: Verdict={r['verdict']} | SpoofType={r['spoof_type']} | is_real={r['is_real']} | Dur={r['duration']:.1f}s | FaceCov={r['face_ratio']:.1%} | Quality={r['quality']} | MeanCorr={r['mean_correlation']:.3f} | B/G={sc.get('bg_ratio', 0.0):.2f} | Lap={sc.get('mean_laplacian', 0.0):.1f} | PeakFrac={r['peak_fraction']:.3f} | SNR={r['snr_db']:.1f}dB")
        if reasons:
            print(f"   -> Cues: {reasons}")

