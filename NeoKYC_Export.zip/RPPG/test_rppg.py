import os
import sys
import unittest
import numpy as np

# Ensure RPPG directory is on path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from rppg import (
    compute_cross_correlation,
    compute_cardiac_coherence,
    evaluate_multipatch_liveness,
    evaluate_display_replay_risk,
    check_temporal_consistency,
    estimate_bpm_and_sqi,
    MIN_BPM,
    MAX_BPM,
)


class TestRppgDeepfakeDetection(unittest.TestCase):

    def setUp(self):
        self.fps = 30.0
        self.duration = 10.0  # 10-second clip as described in FakeCatcher
        self.n_samples = int(self.fps * self.duration)
        self.t = np.linspace(0, self.duration, self.n_samples, endpoint=False)

    def test_cross_correlation_identical_signals(self):
        sig1 = np.sin(2.0 * np.pi * 1.2 * self.t)  # 72 BPM
        sig2 = np.sin(2.0 * np.pi * 1.2 * self.t)
        corr = compute_cross_correlation(sig1, sig2)
        self.assertAlmostEqual(corr, 1.0, places=2)

    def test_cross_correlation_small_arterial_delay(self):
        # Arterial transit time from carotid to facial branches is ~10-40 ms (< 2 frames at 30fps)
        sig1 = np.sin(2.0 * np.pi * 1.2 * self.t)
        sig2 = np.sin(2.0 * np.pi * 1.2 * (self.t - 0.03))
        corr = compute_cross_correlation(sig1, sig2, max_lag=3)
        self.assertGreater(corr, 0.85)

    def test_cross_correlation_discordant_signals(self):
        sig1 = np.sin(2.0 * np.pi * 1.2 * self.t)  # 72 BPM
        sig2 = np.sin(2.0 * np.pi * 1.9 * self.t)  # 114 BPM
        corr = compute_cross_correlation(sig1, sig2, max_lag=3)
        self.assertLess(corr, 0.35)

    def test_evaluate_multipatch_liveness_real_face(self):
        # Genuine human subject: Forehead, Left Cheek, and Right Cheek
        # all reflect the systemic cardiac pulse wave at ~75 BPM
        cardiac_hz = 75.0 / 60.0
        forehead = np.sin(2.0 * np.pi * cardiac_hz * self.t)
        left_cheek = np.sin(2.0 * np.pi * cardiac_hz * (self.t - 0.02))
        right_cheek = np.sin(2.0 * np.pi * cardiac_hz * (self.t - 0.02))

        patches = {
            "Forehead": forehead,
            "Left Cheek": left_cheek,
            "Right Cheek": right_cheek,
        }

        result = evaluate_multipatch_liveness(patches, self.fps)

        self.assertTrue(result["is_real"])
        self.assertEqual(result["verdict"], "REAL_FACE_VERIFIED")
        self.assertGreater(result["mean_correlation"], 0.65)
        self.assertLessEqual(result["max_freq_discrepancy"], 5.0)
        self.assertAlmostEqual(result["consensus_bpm"], 75.0, delta=4.0)

    def test_evaluate_multipatch_liveness_deepfake_discordant(self):
        # Deepfake / AI Face Swap: Forehead and cheeks have independent,
        # asynchronous synthetic noise or differing frequency artifacts
        forehead = np.sin(2.0 * np.pi * (65.0 / 60.0) * self.t)
        left_cheek = np.sin(2.0 * np.pi * (115.0 / 60.0) * self.t)
        right_cheek = np.sin(2.0 * np.pi * 2.8 * self.t) * np.cos(2.0 * np.pi * 0.4 * self.t)

        patches = {
            "Forehead": forehead,
            "Left Cheek": left_cheek,
            "Right Cheek": right_cheek,
        }

        result = evaluate_multipatch_liveness(patches, self.fps)

        self.assertFalse(result["is_real"])
        self.assertEqual(result["verdict"], "DEEPFAKE_SPOOF_DETECTED")
        self.assertTrue(
            result["max_freq_discrepancy"] > 10.0 or result["mean_correlation"] < 0.40
        )

    def test_evaluate_display_replay_risk_natural_skin(self):
        # Natural human skin: R > G > B, B/G around 0.65, low moire
        natural_rgb = [[140.0, 95.0, 62.0] for _ in range(50)]
        laplacian_scores = [8.0 for _ in range(50)]
        risk = evaluate_display_replay_risk(
            natural_rgb,
            laplacian_scores=laplacian_scores,
            peak_fraction=0.35,
            snr_db=3.5,
            mean_corr=0.72,
        )
        self.assertFalse(risk["is_screen_replay"])
        self.assertLess(risk["risk_score"], 0.30)
        self.assertLess(risk["bg_ratio"], 0.85)

    def test_evaluate_display_replay_risk_screen_blue_shift(self):
        # Display screen replay: cold blue backlight (B/G >= 0.95), elevated moire
        screen_rgb = [[110.0, 105.0, 115.0] for _ in range(50)]  # B > G
        laplacian_scores = [65.0 for _ in range(50)]  # high subpixel moire
        risk = evaluate_display_replay_risk(
            screen_rgb,
            laplacian_scores=laplacian_scores,
            peak_fraction=0.18,
            snr_db=-6.0,
            mean_corr=0.15,
        )
        self.assertTrue(risk["is_screen_replay"])
        self.assertGreaterEqual(risk["risk_score"], 0.50)
        self.assertGreaterEqual(risk["bg_ratio"], 0.95)

    def test_evaluate_multipatch_liveness_screen_replay_rejection(self):
        # Screen replay attack with cold display backlight and screen moire cues
        # Even if inter-patch correlation is moderate from phone movement,
        # screen replay cues reject it from genuine verification.
        cardiac_hz = 72.0 / 60.0
        sig = np.sin(2.0 * np.pi * cardiac_hz * self.t)
        patches = {
            "Forehead": sig,
            "Left Cheek": sig,
            "Right Cheek": sig,
        }
        screen_cues = {
            "is_screen_replay": True,
            "risk_score": 0.85,
            "reasons": ["Elevated Blue-to-Green ratio (B/G = 1.05 >= 0.95)"],
            "bg_ratio": 1.05,
        }
        result = evaluate_multipatch_liveness(patches, self.fps, screen_cues=screen_cues)
        self.assertFalse(result["is_real"])
        self.assertTrue(result["is_spoof"])
        self.assertEqual(result["verdict"], "SCREEN_REPLAY_SPOOF_DETECTED")
        self.assertEqual(result["spoof_type"], "SCREEN_REPLAY_ATTACK")

    def test_evaluate_multipatch_liveness_low_quality_inconclusive(self):
        # Low signal quality / weak signal without positive attack cues:
        # must produce INCONCLUSIVE, NOT a spoof claim and NOT real
        noise1 = np.random.RandomState(42).randn(self.n_samples)
        noise2 = np.random.RandomState(43).randn(self.n_samples)
        noise3 = np.random.RandomState(44).randn(self.n_samples)
        patches = {
            "Forehead": noise1,
            "Left Cheek": noise2,
            "Right Cheek": noise3,
        }
        result = evaluate_multipatch_liveness(patches, self.fps, screen_cues=None)
        self.assertFalse(result["is_real"])
        self.assertEqual(result["verdict"], "INCONCLUSIVE")

    def test_temporal_consistency_pure_noise_rejected(self):
        # Pure white/Gaussian noise should NOT maintain stable peak frequencies across overlapping sub-windows
        rng = np.random.RandomState(12345)
        inconsistent_count = 0
        trials = 25
        for _ in range(trials):
            noise = rng.randn(self.n_samples)
            is_consistent, diff, bpm1, bpm2 = check_temporal_consistency(noise, self.fps)
            if not is_consistent:
                inconsistent_count += 1
        # Over 85% of pure noise trials must be rejected by temporal consistency
        self.assertGreaterEqual(inconsistent_count / trials, 0.85)

    def test_temporal_consistency_true_cardiac_pulse_accepted(self):
        # Clean cardiac pulse with steady 72 BPM must be temporally consistent across sub-windows
        cardiac_hz = 72.0 / 60.0
        clean_pulse = np.sin(2.0 * np.pi * cardiac_hz * self.t) + 0.2 * np.sin(4.0 * np.pi * cardiac_hz * self.t)
        is_consistent, diff, bpm1, bpm2 = check_temporal_consistency(clean_pulse, self.fps)
        self.assertTrue(is_consistent)
        self.assertLessEqual(diff, 5.5)

    def test_common_mode_noise_rejected_or_not_verified(self):
        # When pure common-mode noise (e.g. ambient lighting flicker / auto-exposure)
        # affects all patches simultaneously, it must NOT be verified as a REAL_FACE_VERIFIED
        rng = np.random.RandomState(999)
        common_noise = rng.randn(self.n_samples)
        patches = {
            "Forehead": common_noise + 0.1 * rng.randn(self.n_samples),
            "Left Cheek": common_noise + 0.1 * rng.randn(self.n_samples),
            "Right Cheek": common_noise + 0.1 * rng.randn(self.n_samples),
        }
        result = evaluate_multipatch_liveness(patches, self.fps)
        self.assertFalse(result["is_real"])
        self.assertNotEqual(result["verdict"], "REAL_FACE_VERIFIED")



if __name__ == "__main__":
    unittest.main()
