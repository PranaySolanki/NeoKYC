import argparse
import csv
from datetime import datetime
import os
import sys
import warnings

# Suppress internal TensorFlow / MediaPipe C++ log spam
os.environ.setdefault("GLOG_minloglevel", "2")
os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "2")

import cv2
import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import butter, sosfiltfilt, welch, coherence, detrend

# MediaPipe imports supporting both modern tasks API and legacy solutions API
try:
    import mediapipe as mp
except ImportError:
    mp = None

try:
    from mediapipe.tasks import python as mp_python
    from mediapipe.tasks.python import vision as mp_vision
except (ImportError, AttributeError):
    mp_python = None
    mp_vision = None


MIN_BPM = 45.0
MAX_BPM = 180.0
WINDOW_SECONDS = 1.6
RECOMMENDED_MIN_DURATION_SEC = 30.0
ABSOLUTE_MIN_DURATION_SEC = 20.0
DEFAULT_MAX_GAP_SEC = 1.0

# Anatomically defined MediaPipe Face Mesh landmark indices
# Forehead: Glabella to upper forehead between eyebrows and hairline
FOREHEAD_POLYGON = [10, 338, 297, 336, 9, 107, 68, 109]
# Left cheek (subject's right / camera left)
LEFT_CHEEK_POLYGON = [117, 118, 101, 205, 187, 147, 123, 50]
# Right cheek (subject's left / camera right)
RIGHT_CHEEK_POLYGON = [346, 347, 330, 425, 411, 376, 352, 280]

# --- Presentation Attack Detection (PAD) & Liveness Configurable Thresholds ---
# FakeCatcher inter-patch coherence thresholds:
MIN_MEAN_CORRELATION = 0.45
MAX_FREQ_DISCREPANCY_BPM = 6.0
DEEPFAKE_DISCORDANT_FREQ_BPM = 12.0
DEEPFAKE_MISMATCH_CORR = 0.20

# Display / Screen Replay Presentation Attack Thresholds:
# Natural human skin reflectance has R > G > B with Blue/Green ratio (B/G) typically 0.50 - 0.85.
# Electronic displays have strong blue backlight emission peaks (~450 nm) yielding B/G >= 0.95.
DISPLAY_MAX_BG_RATIO = 0.95
DISPLAY_MAX_RG_RATIO = 2.20
DISPLAY_MIN_RG_RATIO = 0.92
# High-frequency texture / moire threshold on facial skin crop (Laplacian variance)
DISPLAY_MOIRE_LAPLACIAN_VAR = 35.0
# Rigid illumination motion correlation threshold across R, G, B channels
RIGID_MOTION_CHANNEL_CORR = 0.96


# ---------------- FACE DETECTOR / BACKENDS ----------------

class FaceDetector:
    """
    Face detector supporting:
      1. MediaPipe Tasks FaceLandmarker (MediaPipe >= 1.0, 478 landmarks)
      2. Legacy MediaPipe Solutions FaceMesh (MediaPipe <= 0.10)
      3. OpenCV Haar Cascade (Fast baseline fallback)
    """

    def __init__(self, mode="auto", model_path="face_landmarker.task"):
        self.mode = mode.lower()
        self.model_path = model_path
        self.backend = None
        self.detector = None
        self.haar_cascade = None

        if not os.path.isabs(self.model_path) and not os.path.exists(self.model_path):
            script_dir = os.path.dirname(os.path.abspath(__file__))
            candidate = os.path.join(script_dir, self.model_path)
            if os.path.exists(candidate):
                self.model_path = candidate

        self._init_backend()

    def _init_backend(self):
        # 1. MediaPipe Tasks FaceLandmarker (Preferred landmark tracking)
        if self.mode in ("auto", "mediapipe"):
            if mp_vision is not None and mp_python is not None and os.path.exists(self.model_path):
                try:
                    base_options = mp_python.BaseOptions(model_asset_path=self.model_path)
                    options = mp_vision.FaceLandmarkerOptions(
                        base_options=base_options,
                        num_faces=1,
                        min_face_detection_confidence=0.2,
                        min_face_presence_confidence=0.2,
                        min_tracking_confidence=0.2,
                    )
                    self.detector = mp_vision.FaceLandmarker.create_from_options(options)
                    self.backend = "mediapipe_tasks"
                    return
                except Exception:
                    pass

            # 2. Legacy MediaPipe Solutions FaceMesh
            if mp is not None and hasattr(mp, "solutions") and hasattr(mp.solutions, "face_mesh"):
                try:
                    self.detector = mp.solutions.face_mesh.FaceMesh(
                        static_image_mode=False,
                        max_num_faces=1,
                        refine_landmarks=False,
                        min_detection_confidence=0.5,
                        min_tracking_confidence=0.5,
                    )
                    self.backend = "mediapipe_solutions"
                    return
                except Exception:
                    pass

        # 3. OpenCV Haar Cascade (Always available with OpenCV)
        cascade_file = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
        self.haar_cascade = cv2.CascadeClassifier(cascade_file)
        self.backend = "opencv_haar"

    def detect(self, frame, rgb_frame):
        """
        Detects face and returns:
          {"type": "landmarks", "landmarks": lm} or
          {"type": "bbox", "bbox": (x, y, w, h)} or
          None
        """
        # 1. MediaPipe Tasks
        if self.backend == "mediapipe_tasks" and self.detector is not None:
            try:
                mp_img = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb_frame)
                res = self.detector.detect(mp_img)
                if res.face_landmarks and len(res.face_landmarks) > 0:
                    return {"type": "landmarks", "landmarks": res.face_landmarks[0]}
            except Exception:
                pass

        # 2. MediaPipe Solutions
        elif self.backend == "mediapipe_solutions" and self.detector is not None:
            try:
                res = self.detector.process(rgb_frame)
                if res.multi_face_landmarks:
                    return {"type": "landmarks", "landmarks": res.multi_face_landmarks[0]}
            except Exception:
                pass

        # 3. Haar Cascade fallback
        if self.haar_cascade is None:
            cascade_file = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
            self.haar_cascade = cv2.CascadeClassifier(cascade_file)

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = self.haar_cascade.detectMultiScale(
            gray,
            scaleFactor=1.1,
            minNeighbors=4,
            minSize=(40, 40),
        )
        if len(faces) > 0:
            x, y, w, h = max(faces, key=lambda b: b[2] * b[3])
            return {"type": "bbox", "bbox": (int(x), int(y), int(w), int(h))}

        return None

    def close(self):
        if self.detector is not None:
            try:
                self.detector.close()
            except Exception:
                pass


# ---------------- ROI SKIN EXTRACTION ----------------

def extract_roi_patch(frame, landmarks, poly_indices):
    """
    Extracts mean RGB from a fast cropped landmark polygon patch.
    """
    h, w = frame.shape[:2]
    # Extract landmark coordinates
    if hasattr(landmarks, "landmark"):
        pts_norm = [[landmarks.landmark[i].x, landmarks.landmark[i].y] for i in poly_indices]
    else:
        pts_norm = [[landmarks[i].x, landmarks[i].y] for i in poly_indices]

    pts = np.array([[int(px * w), int(py * h)] for px, py in pts_norm], dtype=np.int32)
    x_min, y_min = np.clip(pts.min(axis=0), [0, 0], [w - 1, h - 1])
    x_max, y_max = np.clip(pts.max(axis=0), [0, 0], [w - 1, h - 1])

    if x_max - x_min < 5 or y_max - y_min < 5:
        return None

    crop = frame[y_min:y_max + 1, x_min:x_max + 1]
    if crop.size == 0:
        return None

    local_pts = pts - [x_min, y_min]
    mask = np.zeros((crop.shape[0], crop.shape[1]), dtype=np.uint8)
    cv2.fillPoly(mask, [local_pts], 255)

    pixels = crop[mask == 255]
    if len(pixels) < 20:
        return None

    # Filter dark and saturated illumination artifacts
    brightness = pixels.mean(axis=1)
    valid = (brightness > 20) & (brightness < 245)
    if valid.sum() < 20:
        return None

    mean_bgr = pixels[valid].mean(axis=0)
    return mean_bgr[::-1]  # Return RGB


def extract_patches_from_landmarks(frame, landmarks):
    """
    Extracts mean RGB from Forehead, Left Cheek, and Right Cheek individually,
    as well as their spatially averaged combined RGB.
    """
    fh = extract_roi_patch(frame, landmarks, FOREHEAD_POLYGON)
    lc = extract_roi_patch(frame, landmarks, LEFT_CHEEK_POLYGON)
    rc = extract_roi_patch(frame, landmarks, RIGHT_CHEEK_POLYGON)

    valid_patches = [p for p in [fh, lc, rc] if p is not None]
    combined = np.mean(valid_patches, axis=0) if valid_patches else None

    return {
        "combined": combined,
        "forehead": fh,
        "left_cheek": lc,
        "right_cheek": rc,
    }


def extract_rgb_from_landmarks(frame, landmarks):
    """
    Extracts mean RGB from anatomically aligned Forehead, Left Cheek, and Right Cheek.
    Averages the three region means with equal spatial weighting.
    """
    patches = extract_patches_from_landmarks(frame, landmarks)
    return patches["combined"]


def extract_patches_from_box(frame, x, y, face_w, face_h):
    """
    Fallback skin extraction using relative percentage patches when landmarks are unavailable.
    """
    height, width = frame.shape[:2]
    if face_w < 40 or face_h < 40:
        return {"combined": None, "forehead": None, "left_cheek": None, "right_cheek": None}

    region_defs = {
        "forehead": (0.25, 0.12, 0.75, 0.30),
        "left_cheek": (0.12, 0.43, 0.37, 0.63),
        "right_cheek": (0.63, 0.43, 0.88, 0.63),
    }

    out = {}
    valid_list = []
    for name, (x1, y1, x2, y2) in region_defs.items():
        left = max(0, x + int(x1 * face_w))
        right = min(width, x + int(x2 * face_w))
        top = max(0, y + int(y1 * face_h))
        bottom = min(height, y + int(y2 * face_h))

        patch = frame[top:bottom, left:right]
        if patch.size == 0:
            out[name] = None
            continue

        pixels = patch.reshape(-1, 3)
        brightness = pixels.mean(axis=1)
        valid = (brightness > 20) & (brightness < 245)
        if valid.sum() < 20:
            out[name] = None
            continue

        mean_rgb = pixels[valid].mean(axis=0)[::-1]
        out[name] = mean_rgb
        valid_list.append(mean_rgb)

    out["combined"] = np.mean(valid_list, axis=0) if valid_list else None
    return out


def extract_rgb_from_box(frame, x, y, face_w, face_h):
    """
    Fallback skin extraction using relative percentage patches when landmarks are unavailable.
    """
    return extract_patches_from_box(frame, x, y, face_w, face_h)["combined"]


def extract_rgb(frame, face_landmarks):
    """
    Backward compatibility wrapper.
    """
    return extract_rgb_from_landmarks(frame, face_landmarks)


# ---------------- POS ALGORITHM ----------------

def pos_signal(rgb, fps, window_seconds=WINDOW_SECONDS):
    """
    POS (Plane-Orthogonal-to-Skin) rPPG extraction algorithm.
    rgb: (N, 3) array ordered [R, G, B].
    """
    window = max(8, int(window_seconds * fps))
    count = len(rgb)

    output = np.zeros(count, dtype=float)
    weights = np.zeros(count, dtype=float)

    for start in range(0, count - window + 1):
        end = start + window
        segment = rgb[start:end].copy()

        means = segment.mean(axis=0)
        if np.any(means < 1e-6):
            continue

        normalized = segment / means
        r = normalized[:, 0]
        g = normalized[:, 1]
        b = normalized[:, 2]

        s1 = g - b
        s2 = g + b - 2.0 * r

        std1 = np.std(s1)
        std2 = np.std(s2)
        if std2 < 1e-8:
            continue

        alpha = std1 / std2
        h = s1 + alpha * s2
        h -= h.mean()

        output[start:end] += h
        weights[start:end] += 1.0

    valid = weights > 0
    if not np.any(valid):
        raise ValueError("POS could not produce a valid signal.")

    output[valid] /= weights[valid]
    return output


# ---------------- SIGNAL PROCESSING & METRICS ----------------

def bandpass_signal(signal, fps):
    low_hz = MIN_BPM / 60.0
    high_hz = min(MAX_BPM / 60.0, fps * 0.45)

    if high_hz <= low_hz:
        raise ValueError("Video FPS is too low for the selected pulse band.")

    sos = butter(3, [low_hz, high_hz], btype="bandpass", fs=fps, output="sos")
    if len(signal) < 30:
        raise ValueError("Video is too short to filter reliably.")

    return sosfiltfilt(sos, signal)


def estimate_bpm_and_sqi(signal, fps):
    """
    Computes pulse frequency spectrum, estimated BPM, peak prominence fraction,
    and Signal-to-Noise Ratio (SNR in dB) within the cardiac band.
    """
    nperseg = min(len(signal), int(8 * fps))
    frequencies, power = welch(signal, fs=fps, nperseg=nperseg)

    valid_mask = (frequencies >= MIN_BPM / 60.0) & (frequencies <= MAX_BPM / 60.0)
    if not np.any(valid_mask):
        raise ValueError("No frequencies in the selected pulse range.")

    candidate_freqs = frequencies[valid_mask]
    candidate_power = power[valid_mask]

    peak_idx = np.argmax(candidate_power)
    peak_hz = candidate_freqs[peak_idx]
    bpm = peak_hz * 60.0

    # Cardiac fundamental peak window: +/- 0.24 Hz (covers complete Hann main lobe without harmonic)
    half_window_hz = 0.24
    peak_band_mask = np.abs(candidate_freqs - peak_hz) <= half_window_hz
    signal_power = np.sum(candidate_power[peak_band_mask])
    total_inband_power = np.sum(candidate_power)

    peak_fraction = float(signal_power / total_inband_power) if total_inband_power > 0 else 0.0

    noise_power = total_inband_power - signal_power
    if noise_power > 0 and signal_power > 0:
        snr_db = 10.0 * np.log10(signal_power / noise_power)
    else:
        snr_db = 0.0

    return float(bpm), peak_fraction, snr_db, frequencies, power


def check_temporal_consistency(signal, fps):
    """
    Checks that pulse frequency remains consistent (+/- 5.5 BPM) across overlapping sub-windows.
    Pure noise has erratic peak locations across sub-windows, while true cardiac pulses stay stable.
    """
    n = len(signal)
    sub_len = int(0.70 * n)
    if sub_len < 32 or n < 48:
        return False, 0.0, 0.0, 0.0

    sub1 = signal[:sub_len]
    sub2 = signal[n - sub_len:]

    try:
        bpm1, pf1, snr1, _, _ = estimate_bpm_and_sqi(sub1, fps)
        bpm2, pf2, snr2, _, _ = estimate_bpm_and_sqi(sub2, fps)
    except Exception:
        return False, 999.0, 0.0, 0.0

    diff = abs(bpm1 - bpm2)
    is_consistent = (diff <= 5.5) and (pf1 >= 0.20) and (pf2 >= 0.20)
    return is_consistent, diff, bpm1, bpm2


def compute_cross_correlation(x, y, max_lag=3):
    """
    Computes maximum Pearson cross-correlation between two signals allowing a small
    physiological arterial pulse transit delay (max_lag frames).
    """
    n = min(len(x), len(y))
    if n < 8:
        return 0.0

    x_c = x[:n] - np.mean(x[:n])
    y_c = y[:n] - np.mean(y[:n])
    denom = np.sqrt(np.sum(x_c ** 2) * np.sum(y_c ** 2))
    if denom < 1e-12:
        return 0.0

    best_r = -1.0
    for lag in range(-max_lag, max_lag + 1):
        if lag < 0:
            val = np.sum(x_c[:lag] * y_c[-lag:])
        elif lag > 0:
            val = np.sum(x_c[lag:] * y_c[:-lag])
        else:
            val = np.sum(x_c * y_c)
        r = val / denom
        if r > best_r:
            best_r = r
    return float(np.clip(best_r, -1.0, 1.0))


def compute_cardiac_coherence(x, y, fps):
    """
    Computes magnitude-squared coherence Cxy(f) within the cardiac pulse band (0.7 - 3.0 Hz).
    """
    n = min(len(x), len(y))
    if n < 16:
        return 0.0, np.array([]), np.array([])

    nperseg = min(n, int(4.5 * fps))
    freqs, cxy = coherence(x[:n], y[:n], fs=fps, nperseg=nperseg)
    valid_mask = (freqs >= MIN_BPM / 60.0) & (freqs <= MAX_BPM / 60.0)
    if not np.any(valid_mask):
        return 0.0, freqs, cxy
    mean_inband_coherence = float(np.mean(cxy[valid_mask]))
    return mean_inband_coherence, freqs, cxy


def evaluate_display_replay_risk(
    rgb_samples,
    laplacian_scores=None,
    depth_ratios=None,
    peak_fraction=0.0,
    snr_db=0.0,
    mean_corr=0.0,
):
    """
    Evaluates risk of a Screen / Display Replay Presentation Attack (phone, tablet, monitor).

    Biophysical & Hardware Presentation Cues:
    1. Chrominance Spectrum:
       Human skin under natural/broadband light has R > G > B with Blue/Green ratio (B/G)
       typically in 0.45 - 0.88. Electronic displays emit narrow-band cold LED backlights with
       blue peaks (~450 nm), yielding elevated B/G >= 0.95 or extreme R/G (>= 2.20).
    2. Spatial Texture / Moire:
       Digital screens recorded by digital cameras create periodic subpixel grid interference
       patterns (moire), elevating high-frequency Laplacian variance on facial skin.
    3. Channel Illuminance Rigidity:
       When a display device is held/moved, all channels fluctuate in lockstep (corr > 0.96)
       without the green-dominant pulsatile micro-dynamics typical of true human blood perfusion.
    4. Planar Surface Relief:
       Flat displays exhibit invariant/planar depth profiles lacking true 3D facial relief.
    """
    reasons = []
    risk_score = 0.0

    valid_samples = [s for s in rgb_samples if s is not None and not np.any(np.isnan(s))]
    if len(valid_samples) < 15:
        return {
            "is_screen_replay": False,
            "risk_score": 0.0,
            "reasons": ["Insufficient valid samples for display analysis"],
            "bg_ratio": 0.0,
            "rg_ratio": 0.0,
            "mean_laplacian": 0.0,
            "depth_ratio_std": 0.0,
        }

    arr = np.array(valid_samples)
    r_mean = float(np.mean(arr[:, 0]))
    g_mean = float(np.mean(arr[:, 1]))
    b_mean = float(np.mean(arr[:, 2]))

    rg_ratio = r_mean / max(1e-4, g_mean)
    bg_ratio = b_mean / max(1e-4, g_mean)

    # Spatial texture / Moire
    mean_lap = float(np.mean(laplacian_scores)) if laplacian_scores and len(laplacian_scores) > 0 else 0.0
    has_moire = mean_lap >= DISPLAY_MOIRE_LAPLACIAN_VAR

    # Channel Illuminance Rigidity
    r_ts = arr[:, 0]
    g_ts = arr[:, 1]
    b_ts = arr[:, 2]

    corr_rg = float(np.corrcoef(r_ts, g_ts)[0, 1]) if len(r_ts) > 5 else 0.0
    corr_gb = float(np.corrcoef(g_ts, b_ts)[0, 1]) if len(g_ts) > 5 else 0.0
    is_rigid_illum = (
        corr_rg >= RIGID_MOTION_CHANNEL_CORR
        and corr_gb >= RIGID_MOTION_CHANNEL_CORR
        and peak_fraction < 0.20
        and snr_db < -4.0
    )

    # Planar depth variance
    depth_std = float(np.std(depth_ratios)) if depth_ratios and len(depth_ratios) > 10 else 0.0

    # 1. Chrominance distribution check
    # Extreme Blue Inversion (B/G >= 1.05): Blue strictly and substantially exceeds green reflectance.
    has_extreme_blue = bg_ratio >= 1.05
    has_blue_shift = bg_ratio >= DISPLAY_MAX_BG_RATIO
    has_saturation_skew = rg_ratio >= DISPLAY_MAX_RG_RATIO or rg_ratio <= DISPLAY_MIN_RG_RATIO

    if has_extreme_blue:
        reasons.append(f"Inverted Blue-to-Green ratio (B/G = {bg_ratio:.2f} >= 1.05), characteristic of display backlight")
        risk_score += 0.55
    elif has_blue_shift and (has_moire or is_rigid_illum or (depth_std < 0.015 and len(depth_ratios or []) > 10)):
        reasons.append(f"Elevated Blue-to-Green ratio (B/G = {bg_ratio:.2f} >= {DISPLAY_MAX_BG_RATIO:.2f}) with corroborating display cues")
        risk_score += 0.55
    elif has_blue_shift:
        reasons.append(f"Elevated Blue-to-Green ratio (B/G = {bg_ratio:.2f} >= {DISPLAY_MAX_BG_RATIO:.2f})")
        risk_score += 0.20

    if has_saturation_skew:
        reasons.append(f"Unnatural Red-to-Green ratio (R/G = {rg_ratio:.2f}), outside natural skin reflectance range")
        risk_score += 0.30

    # 2. Spatial texture / Moire check
    if has_moire:
        reasons.append(f"Elevated high-frequency spatial texture/moire (Laplacian var = {mean_lap:.1f} >= {DISPLAY_MOIRE_LAPLACIAN_VAR:.1f})")
        risk_score += 0.40

    # 3. Channel Illuminance Rigidity check
    if is_rigid_illum:
        reasons.append(f"Rigid full-frame illumination swing (channel corr = {min(corr_rg, corr_gb):.3f}) with absent cardiac pulse (SNR = {snr_db:.1f} dB)")
        risk_score += 0.40

    # 4. Planar depth variance check
    if is_rigid_illum and depth_std < 0.015 and len(depth_ratios or []) > 10:
        reasons.append(f"Planar 2D presentation surface (depth variance = {depth_std:.4f})")
        risk_score += 0.25

    # Corroborating flat pulse check with elevated blue shift
    if peak_fraction < 0.18 and snr_db < -6.0 and (has_extreme_blue or has_moire or is_rigid_illum):
        risk_score += 0.20
        reasons.append(f"Flat cardiac spectrum (peak frac = {peak_fraction:.3f}, SNR = {snr_db:.1f} dB) confirming lack of biological pulse")

    is_screen_replay = (risk_score >= 0.55) or (has_blue_shift and (has_moire or is_rigid_illum))

    return {
        "is_screen_replay": is_screen_replay,
        "risk_score": float(np.clip(risk_score, 0.0, 1.0)),
        "reasons": reasons,
        "bg_ratio": bg_ratio,
        "rg_ratio": rg_ratio,
        "mean_laplacian": mean_lap,
        "depth_ratio_std": depth_std,
    }


def evaluate_multipatch_liveness(patches_dict, fps, screen_cues=None):
    """
    Evaluates multi-region spatiotemporal rPPG coherence across Forehead, Left Cheek,
    and Right Cheek based on FakeCatcher / multi-patch biological pulse principles,
    incorporating Display Replay and Synthetic Deepfake Presentation Attack Detection (PAD).

    In a genuine live human:
    - Supraorbital and facial arterial branches deliver systemic pulse waves simultaneously.
    - Inter-patch signals show high cross-correlation (>0.55), high spectral coherence (>0.50),
      and identical cardiac frequency (<6 BPM spread).
    - Skin reflectance shows natural subcutaneous scattering with R > G > B and healthy B/G <= 0.88.

    In presentation attacks:
    - Deepfakes / AI face swaps: synthesis lacks arterial modeling, producing discordant frequencies
      across facial territories or synthetic decorrelated noise.
    - Display replay attacks: electronic screens exhibit blue emission peaks (B/G >= 0.95), moire patterns,
      and lack true physiological green-dominant micro-pulsation under rigid illumination movement.
    """
    patch_metrics = {}
    patch_names = list(patches_dict.keys())

    for name, sig in patches_dict.items():
        if len(sig) < 20:
            continue
        try:
            bpm, peak_frac, snr, f, p = estimate_bpm_and_sqi(sig, fps)
            patch_metrics[name] = {
                "bpm": bpm,
                "peak_fraction": peak_frac,
                "snr_db": snr,
                "frequencies": f,
                "power": p,
            }
        except Exception:
            patch_metrics[name] = {
                "bpm": 0.0,
                "peak_fraction": 0.0,
                "snr_db": 0.0,
                "frequencies": np.array([]),
                "power": np.array([]),
            }

    if len(patch_names) < 2:
        single_bpm = patch_metrics.get(patch_names[0], {}).get("bpm", 0.0) if patch_names else 0.0
        return {
            "patch_metrics": patch_metrics,
            "pairwise_correlations": {},
            "mean_correlation": 0.0,
            "pairwise_coherences": {},
            "coherence_curves": {},
            "mean_coherence": 0.0,
            "max_freq_discrepancy": 0.0,
            "consensus_bpm": single_bpm,
            "verdict": "INCONCLUSIVE",
            "verdict_title": "INCONCLUSIVE — INSUFFICIENT PATCHES",
            "verdict_description": "At least 2 facial skin patches are required for coherence analysis.",
            "is_real": False,
            "is_spoof": False,
            "spoof_type": None,
            "screen_cues": screen_cues,
        }

    # 1. Pairwise Cross-Correlations
    max_lag = max(1, int(0.15 * fps))
    correlations = {}
    for i in range(len(patch_names)):
        for j in range(i + 1, len(patch_names)):
            n1 = patch_names[i]
            n2 = patch_names[j]
            r = compute_cross_correlation(patches_dict[n1], patches_dict[n2], max_lag=max_lag)
            correlations[f"{n1} <-> {n2}"] = r
    mean_corr = float(np.mean(list(correlations.values()))) if correlations else 0.0

    # 2. Pairwise Spectral Coherence
    coherences = {}
    coherence_curves = {}
    for i in range(len(patch_names)):
        for j in range(i + 1, len(patch_names)):
            n1 = patch_names[i]
            n2 = patch_names[j]
            c_mean, c_freqs, c_xy = compute_cardiac_coherence(patches_dict[n1], patches_dict[n2], fps)
            coherences[f"{n1} <-> {n2}"] = c_mean
            coherence_curves[f"{n1} <-> {n2}"] = (c_freqs, c_xy)
    mean_coherence = float(np.mean(list(coherences.values()))) if coherences else 0.0

    # 3. Frequency Discrepancy
    # A meaningful cardiac frequency requires distinct in-band peak prominence (peak_fraction >= 0.22).
    # Weak, noisy signals must not be mislabeled as deepfake discordant frequencies.
    valid_bpms = [
        m["bpm"]
        for m in patch_metrics.values()
        if MIN_BPM <= m["bpm"] <= MAX_BPM and m["peak_fraction"] >= 0.22
    ]
    if len(valid_bpms) >= 2:
        max_freq_diff = float(max(valid_bpms) - min(valid_bpms))
    else:
        max_freq_diff = 0.0

    # 4. Consensus BPM (weighted by peak power fraction)
    weights = [
        max(0.01, m["peak_fraction"])
        for m in patch_metrics.values()
        if MIN_BPM <= m["bpm"] <= MAX_BPM
    ]
    bpms = [
        m["bpm"]
        for m in patch_metrics.values()
        if MIN_BPM <= m["bpm"] <= MAX_BPM
    ]
    if bpms and sum(weights) > 0:
        consensus_bpm = float(np.average(bpms, weights=weights))
    else:
        consensus_bpm = 0.0

    # 4b. Temporal Consistency Check
    # Common-mode sensor noise / illumination drift may match across patches at an instantaneous moment,
    # but does not remain stable across temporal sub-windows. Real cardiac pulses maintain stable BPM.
    temporally_consistent = False
    for name in patch_names:
        sig = patches_dict.get(name)
        if sig is not None and len(sig) >= 48:
            is_c, _, _, _ = check_temporal_consistency(sig, fps)
            if is_c:
                temporally_consistent = True
                break

    # 5. Liveness Classification & Presentation Attack Detection Engine
    has_strong_energy = any(m["peak_fraction"] >= 0.22 for m in patch_metrics.values())
    is_coherent = (
        mean_corr >= MIN_MEAN_CORRELATION
        and max_freq_diff <= MAX_FREQ_DISCREPANCY_BPM
        and len(valid_bpms) >= 2
        and consensus_bpm >= MIN_BPM
        and temporally_consistent
        and (screen_cues is None or not screen_cues.get("is_screen_replay", False))
    )
    # Deepfake detection requires distinct, high-confidence periodic cardiac signals on BOTH patches
    # (peak_fraction >= 0.38 and snr_db >= 1.0 dB).
    # Weak, noisy signals or camera noise must never be labeled as deepfakes.
    strong_bpms = [
        m["bpm"]
        for m in patch_metrics.values()
        if MIN_BPM <= m["bpm"] <= MAX_BPM and m["peak_fraction"] >= 0.38 and m.get("snr_db", 0.0) >= 1.0
    ]
    strong_freq_diff = float(max(strong_bpms) - min(strong_bpms)) if len(strong_bpms) >= 2 else 0.0
    has_discordant_bpm = strong_freq_diff > 16.0 and len(strong_bpms) >= 2
    has_mismatched_waveforms = mean_corr < 0.15 and len(patch_names) >= 2 and all(m["peak_fraction"] >= 0.40 and m.get("snr_db", 0.0) >= 2.0 for m in patch_metrics.values())
    is_deepfake = (has_discordant_bpm or has_mismatched_waveforms) and not is_coherent
    is_screen_replay = bool(screen_cues and screen_cues.get("is_screen_replay", False))

    spoof_type = None
    if is_deepfake:
        verdict = "DEEPFAKE_SPOOF_DETECTED"
        verdict_title = "DEEPFAKE / AI SYNTHETIC FACE DETECTED"
        verdict_description = (
            f"Facial regions exhibit discordant pulsatile rhythms (mean cross-correlation: {mean_corr:.2f}, "
            f"frequency spread: {max_freq_diff:.1f} BPM). Characteristic of deepfake/AI video synthesis."
        )
        spoof_type = "DEEPFAKE_PULSE_INCOHERENCE"
        is_real = False
    elif is_screen_replay:
        verdict = "SCREEN_REPLAY_SPOOF_DETECTED"
        verdict_title = "DISPLAY REPLAY ATTACK DETECTED"
        reasons_summary = "; ".join(screen_cues.get("reasons", ["Screen replay detected"]))
        verdict_description = (
            f"Presentation attack detected: screen display replay cues observed ({reasons_summary})."
        )
        spoof_type = "SCREEN_REPLAY_ATTACK"
        is_real = False
    elif is_coherent:
        verdict = "REAL_FACE_VERIFIED"
        verdict_title = "REAL LIVE HUMAN FACE VERIFIED"
        verdict_description = (
            f"Synchronous biological blood volume pulse confirmed across facial arterial regions "
            f"(mean cross-correlation: {mean_corr:.2f}, consensus BPM: {consensus_bpm:.1f})."
        )
        is_real = True
    else:
        verdict = "INCONCLUSIVE"
        verdict_title = "INCONCLUSIVE — TRY AGAIN"
        verdict_description = (
            f"Signal coherence is marginal or camera conditions were noisy (mean cross-correlation: {mean_corr:.2f})."
        )
        is_real = False

    return {
        "patch_metrics": patch_metrics,
        "pairwise_correlations": correlations,
        "mean_correlation": mean_corr,
        "pairwise_coherences": coherences,
        "coherence_curves": coherence_curves,
        "mean_coherence": mean_coherence,
        "max_freq_discrepancy": max_freq_diff,
        "consensus_bpm": consensus_bpm,
        "verdict": verdict,
        "verdict_title": verdict_title,
        "verdict_description": verdict_description,
        "is_real": is_real,
        "is_spoof": (verdict in ("DEEPFAKE_SPOOF_DETECTED", "SCREEN_REPLAY_SPOOF_DETECTED", "SPOOF_DETECTED")),
        "spoof_type": spoof_type,
        "screen_cues": screen_cues,
    }



def evaluate_quality(duration, fps, face_ratio, max_gap_sec, peak_fraction, snr_db):
    """
    Evaluates signal quality rating and compiles actionable warnings.
    """
    warnings_list = []

    # Duration evaluation
    if duration < ABSOLUTE_MIN_DURATION_SEC:
        duration_verdict = f"TOO SHORT ({duration:.1f}s < {ABSOLUTE_MIN_DURATION_SEC:.0f}s)"
        warnings_list.append(
            f"Recording duration ({duration:.1f}s) is critically short. Frequency resolution "
            f"df is coarse (~{60.0/duration:.1f} BPM). Recommended: 30-45s at 25-30 FPS."
        )
    elif duration < RECOMMENDED_MIN_DURATION_SEC:
        duration_verdict = f"MARGINAL ({duration:.1f}s < {RECOMMENDED_MIN_DURATION_SEC:.0f}s)"
        warnings_list.append(
            f"Recording duration ({duration:.1f}s) is below recommended standard (>= 30.0s). "
            f"Spectral resolution is limited."
        )
    else:
        duration_verdict = f"SUFFICIENT ({duration:.1f}s >= {RECOMMENDED_MIN_DURATION_SEC:.0f}s)"

    # Gap and face tracking evaluation
    if max_gap_sec > 1.0:
        warnings_list.append(
            f"Face tracking lost for {max_gap_sec:.2f}s consecutive. Large missing gaps "
            f"distort pulsatile phase information and degrade rPPG accuracy."
        )

    if face_ratio < 0.85:
        warnings_list.append(
            f"Face patch availability is low ({face_ratio:.1%}). Ensure steady lighting "
            f"and centered face position."
        )

    # Spectral prominence / SNR evaluation
    if peak_fraction < 0.20:
        warnings_list.append(
            f"Low spectral peak prominence ({peak_fraction:.1%}). Likely caused by motion "
            f"artifacts, head movement, or uneven lighting."
        )

    # Overall Quality Tier
    if (
        duration >= RECOMMENDED_MIN_DURATION_SEC
        and face_ratio >= 0.95
        and max_gap_sec <= 0.5
        and peak_fraction >= 0.30
        and snr_db >= 2.0
    ):
        quality_rating = "HIGH QUALITY (Clean signal)"
    elif (
        duration >= ABSOLUTE_MIN_DURATION_SEC
        and face_ratio >= 0.85
        and max_gap_sec <= 1.0
        and peak_fraction >= 0.20
    ):
        quality_rating = "MODERATE QUALITY (Usable estimate)"
    elif duration < ABSOLUTE_MIN_DURATION_SEC or max_gap_sec > 1.5 or face_ratio < 0.80:
        quality_rating = "UNRELIABLE (Validation test only, pulse accuracy unconfirmed)"
    else:
        quality_rating = "MARGINAL (Low confidence, observe warnings)"

    return duration_verdict, quality_rating, warnings_list


def compute_gap_statistics(valid_flags, fps):
    """
    Computes total gaps and maximum consecutive dropped frame sequence in seconds.
    """
    gap_count = 0
    max_gap_frames = 0
    curr_gap_frames = 0

    for is_valid in valid_flags:
        if not is_valid:
            curr_gap_frames += 1
            if curr_gap_frames > max_gap_frames:
                max_gap_frames = curr_gap_frames
        else:
            if curr_gap_frames > 0:
                gap_count += 1
                curr_gap_frames = 0

    if curr_gap_frames > 0:
        gap_count += 1

    max_gap_sec = max_gap_frames / fps if fps > 0 else 0.0
    return gap_count, max_gap_frames, max_gap_sec


def validate_against_reference(estimated_bpm, reference_bpm):
    """
    Computes absolute error and clinical agreement metrics against reference.
    """
    abs_error = abs(estimated_bpm - reference_bpm)
    rel_error = (abs_error / reference_bpm) * 100.0 if reference_bpm > 0 else 0.0

    if abs_error <= 5.0:
        agreement = "PASS (Within +/- 5.0 BPM clinical tolerance)"
    elif abs_error <= 10.0:
        agreement = "ACCEPTABLE (Within +/- 10.0 BPM tolerance)"
    else:
        agreement = "FAIL (Absolute error > 10.0 BPM)"

    return abs_error, rel_error, agreement


def log_validation_result(log_path, record):
    """
    Appends execution metrics to a CSV file for tracking across recordings.
    """
    file_exists = os.path.isfile(log_path)
    fieldnames = [
        "Timestamp",
        "Video_File",
        "Liveness_Verdict",
        "Spatial_Coherence",
        "Mean_Correlation",
        "Freq_Spread_BPM",
        "Duration_s",
        "Nominal_FPS",
        "Actual_Sampling_Rate",
        "Face_Patch_Pct",
        "Max_Gap_s",
        "Estimated_BPM",
        "Reference_BPM",
        "Abs_Error_BPM",
        "Rel_Error_Pct",
        "Peak_Power_Fraction",
        "SNR_dB",
        "Quality_Rating",
        "Detector_Backend",
    ]

    try:
        with open(log_path, mode="a", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            if not file_exists:
                writer.writeheader()
            writer.writerow(record)
        print(f"Validation metrics appended to: {log_path}")
    except Exception as e:
        print(f"Could not write to validation log {log_path}: {e}")


# ---------------- MAIN PIPELINE ----------------

def process_video(
    video_path,
    reference_bpm=None,
    detector_mode="auto",
    save_plot="rppg_plot.png",
    show_plot=True,
    max_gap_threshold=DEFAULT_MAX_GAP_SEC,
    log_file="validation_log.csv",
):
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise ValueError(f"Could not open video: {video_path}")

    fps = cap.get(cv2.CAP_PROP_FPS)
    total_video_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

    if not np.isfinite(fps) or fps < 10:
        cap.release()
        raise ValueError("Invalid or low video FPS. Use a stable video of at least 10 FPS.")

    rgb_samples = []
    forehead_samples = []
    left_cheek_samples = []
    right_cheek_samples = []
    laplacian_scores = []
    depth_ratios = []
    timestamps = []
    valid_flags = []
    frames_seen = 0
    face_frames = 0

    detector = FaceDetector(mode=detector_mode)
    backend_name = (
        f"MediaPipe FaceLandmarker (Landmarks)"
        if detector.backend == "mediapipe_tasks"
        else f"MediaPipe Solutions FaceMesh"
        if detector.backend == "mediapipe_solutions"
        else "OpenCV Haar Cascade (Bounding Box Fallback)"
    )

    try:
        while True:
            ok, frame = cap.read()
            if not ok:
                break

            timestamp = frames_seen / fps
            frames_seen += 1

            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            detection = detector.detect(frame, rgb_frame)

            sample_dict = None
            if detection is not None:
                if detection["type"] == "landmarks":
                    lm = detection["landmarks"]
                    sample_dict = extract_patches_from_landmarks(frame, lm)
                    # Sample high-frequency spatial texture (Laplacian variance) on forehead crop
                    h_f, w_f = frame.shape[:2]
                    lm_items = lm.landmark if hasattr(lm, "landmark") else lm
                    fx = int(lm_items[10].x * w_f)
                    fy = int(lm_items[10].y * h_f)
                    patch_crop = frame[max(0, fy - 25):min(h_f, fy + 25), max(0, fx - 25):min(w_f, fx + 25)]
                    if patch_crop.size > 20:
                        gray_p = cv2.cvtColor(patch_crop, cv2.COLOR_BGR2GRAY)
                        laplacian_scores.append(float(cv2.Laplacian(gray_p, cv2.CV_64F).var()))

                    # Sample 3D depth relief (nose tip vs cheek contours)
                    if len(lm_items) > 454 and hasattr(lm_items[1], "z"):
                        face_w_norm = abs(lm_items[454].x - lm_items[234].x)
                        if face_w_norm > 0.05:
                            mid_z = (lm_items[234].z + lm_items[454].z) / 2.0
                            depth_ratios.append(float((mid_z - lm_items[1].z) / face_w_norm))
                elif detection["type"] == "bbox":
                    x, y, w, h = detection["bbox"]
                    sample_dict = extract_patches_from_box(frame, x, y, w, h)
                    crop_bbox = frame[y:y + h, x:x + w]
                    if crop_bbox.size > 20:
                        gray_b = cv2.cvtColor(crop_bbox, cv2.COLOR_BGR2GRAY)
                        laplacian_scores.append(float(cv2.Laplacian(gray_b, cv2.CV_64F).var()))

            if sample_dict is not None and sample_dict.get("combined") is not None:
                face_frames += 1
                valid_flags.append(True)
                rgb_samples.append(sample_dict["combined"])
                forehead_samples.append(sample_dict["forehead"] if sample_dict["forehead"] is not None else [np.nan, np.nan, np.nan])
                left_cheek_samples.append(sample_dict["left_cheek"] if sample_dict["left_cheek"] is not None else [np.nan, np.nan, np.nan])
                right_cheek_samples.append(sample_dict["right_cheek"] if sample_dict["right_cheek"] is not None else [np.nan, np.nan, np.nan])
            else:
                valid_flags.append(False)
                rgb_samples.append([np.nan, np.nan, np.nan])
                forehead_samples.append([np.nan, np.nan, np.nan])
                left_cheek_samples.append([np.nan, np.nan, np.nan])
                right_cheek_samples.append([np.nan, np.nan, np.nan])

            timestamps.append(timestamp)
    finally:
        cap.release()
        detector.close()

    if frames_seen == 0:
        raise ValueError("The video contains no readable frames.")

    timestamps = np.asarray(timestamps)
    duration = frames_seen / fps
    face_ratio = face_frames / frames_seen
    print(f"Duration: {duration:.2f} seconds")
    print(f"Nominal FPS: {fps:.2f}")
    print(f"Frames with usable face patches: {face_ratio:.1%}")

    if duration < 6.0:
        raise ValueError(
            f"Recording duration ({duration:.1f}s) is critically short. "
            "Record at least 6-10 seconds for reliable rPPG frequency resolution."
        )

    if fps < 20:
        print(
            "WARNING: FPS is below 20. "
            "Pulse estimation may be less reliable."
        )

    if face_ratio < 0.60:
        raise ValueError(
            "Face detection failed in too many frames. "
            "Use a frontal face video with steady lighting."
        )

    # Actual observed sampling rate
    actual_sampling_rate = (frames_seen - 1) / (timestamps[-1] - timestamps[0]) if len(timestamps) > 1 else fps

    # Interpolate short missing gaps per channel
    def interpolate_patch(patch_samples, ts):
        arr = np.asarray(patch_samples, dtype=float)
        for ch in range(3):
            val = arr[:, ch]
            val_valid = np.isfinite(val)
            if val_valid.sum() >= 5:
                arr[:, ch] = np.interp(ts, ts[val_valid], val[val_valid])
            else:
                arr[:, ch] = 0.0
        return arr

    rgb = interpolate_patch(rgb_samples, timestamps)
    forehead_rgb = interpolate_patch(forehead_samples, timestamps)
    left_cheek_rgb = interpolate_patch(left_cheek_samples, timestamps)
    right_cheek_rgb = interpolate_patch(right_cheek_samples, timestamps)

    # Calculate gap statistics
    missing = ~np.isfinite(np.asarray(rgb_samples, dtype=float)).all(axis=1)
    changes = np.diff(np.concatenate(([False], missing, [False])).astype(int))
    starts = np.where(changes == 1)[0]
    ends = np.where(changes == -1)[0]
    gap_lengths = ends - starts
    gap_count = len(starts)
    max_gap_len = int(gap_lengths.max()) if len(gap_lengths) > 0 else 0
    max_gap_sec = max_gap_len / fps

    # Extract POS & Bandpass signals for combined and multi-patch ROIs
    raw_pos = pos_signal(rgb, fps)
    filtered = bandpass_signal(raw_pos, fps)
    bpm, peak_fraction, snr_db, frequencies, power = estimate_bpm_and_sqi(filtered, fps)

    raw_fh = pos_signal(forehead_rgb, fps)
    filtered_fh = bandpass_signal(raw_fh, fps)

    raw_lc = pos_signal(left_cheek_rgb, fps)
    filtered_lc = bandpass_signal(raw_lc, fps)

    raw_rc = pos_signal(right_cheek_rgb, fps)
    filtered_rc = bandpass_signal(raw_rc, fps)

    # Multi-Region Spatiotemporal Coherence Evaluation (FakeCatcher)
    patch_signals = {
        "Forehead": filtered_fh,
        "Left Cheek": filtered_lc,
        "Right Cheek": filtered_rc,
    }

    # Inter-patch mean correlation
    max_lag = max(1, int(0.15 * fps))
    patch_corrs = []
    names = list(patch_signals.keys())
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            patch_corrs.append(compute_cross_correlation(patch_signals[names[i]], patch_signals[names[j]], max_lag=max_lag))
    prelim_mean_corr = float(np.mean(patch_corrs)) if patch_corrs else 0.0

    # Evaluate Display Replay Presentation Attack Risk
    screen_cues = evaluate_display_replay_risk(
        rgb_samples,
        laplacian_scores=laplacian_scores,
        depth_ratios=depth_ratios,
        peak_fraction=peak_fraction,
        snr_db=snr_db,
        mean_corr=prelim_mean_corr,
    )

    liveness = evaluate_multipatch_liveness(patch_signals, fps, screen_cues=screen_cues)
    if liveness["consensus_bpm"] > 0:
        effective_bpm = liveness["consensus_bpm"]
    else:
        effective_bpm = bpm

    # Quality and warning assessment
    duration_verdict, quality_rating, quality_warnings = evaluate_quality(
        duration, fps, face_ratio, max_gap_sec, peak_fraction, snr_db
    )

    # Reference validation
    has_ref = reference_bpm is not None and reference_bpm > 0
    if has_ref:
        abs_error, rel_error, agreement = validate_against_reference(effective_bpm, reference_bpm)
    else:
        abs_error, rel_error, agreement = None, None, None

    # Print comprehensive diagnostic report
    print("\n" + "=" * 70)
    print("      rPPG Pulse Estimation & Deepfake Liveness Detection Report")
    print("=" * 70)
    print(f"Video File:              {os.path.basename(video_path)}")
    print(f"Detector Backend:        {backend_name}")

    print("\n--- 1. Authenticity & Liveness Verdict (FakeCatcher) ---")
    print(f"Liveness Verdict:        [{liveness['verdict']}]")
    print(f"Verdict Title:           {liveness['verdict_title']}")
    print(f"Verdict Summary:         {liveness['verdict_description']}")
    print(f"Spatial Correlation:     {liveness['mean_correlation']:.3f} (Forehead <-> Cheeks zero-lag r)")
    print(f"Spectral Coherence:      {liveness['mean_coherence']:.3f} (In-band cardiac magnitude-squared Cxy)")
    print(f"Max Frequency Spread:    {liveness['max_freq_discrepancy']:.1f} BPM across regions")
    print("Pairwise Region Correlations:")
    for pair, r_val in liveness['pairwise_correlations'].items():
        print(f"  * {pair:24s} r = {r_val:+.3f}")

    print("\n--- 2. Recording & Sampling Characteristics ---")
    print(f"Duration:                {duration:.2f} s")
    print(f"Total Frames Processed:  {frames_seen} frames")
    print(f"Nominal Video FPS:       {fps:.2f} Hz")
    print(f"Actual Sampling Rate:    {actual_sampling_rate:.2f} Hz")
    print(f"Duration Status:         {duration_verdict}")

    print("\n--- 3. Face Tracking & ROI Continuity ---")
    print(f"Usable Face Frames:      {face_frames} / {frames_seen} ({face_ratio:.1%})")
    print(f"Tracking Gaps Count:     {gap_count} incident(s)")
    print(f"Max Consecutive Gap:     {max_gap_sec:.2f} s ({max_gap_len} frames)")
    if max_gap_sec > max_gap_threshold:
        print(f"Gap Warning:             [EXCEEDS {max_gap_threshold:.1f}s THRESHOLD] May distort pulse phase!")
    else:
        print(f"Gap Status:              [PASS] Continuity within {max_gap_threshold:.1f}s threshold")

    print("\n--- 4. Pulse Estimation & Signal Quality Index (SQI) ---")
    print(f"Estimated Pulse:         {effective_bpm:.1f} BPM ({effective_bpm / 60.0:.2f} Hz)")
    print(f"Cardiac Band:            {MIN_BPM:.0f} - {MAX_BPM:.0f} BPM ({MIN_BPM/60:.2f} - {MAX_BPM/60:.2f} Hz)")
    print(f"Peak Power Fraction:     {peak_fraction:.3f} ({peak_fraction * 100:.1f}% in-band energy)")
    print(f"Signal-to-Noise (SNR):   {snr_db:.1f} dB")
    print(f"Signal Quality Rating:   [{quality_rating}]")

    if quality_warnings:
        print("\nSignal Quality Warnings:")
        for w in quality_warnings:
            print(f"  * {w}")

    print("\n--- 5. Reference Validation (Ground Truth) ---")
    if has_ref:
        print(f"Reference BPM:           {reference_bpm:.1f} BPM (from pulse oximeter)")
        print(f"Estimated BPM:           {effective_bpm:.1f} BPM")
        print(f"Absolute Error (AE):     {abs_error:.1f} BPM")
        print(f"Relative Error (MAPE):   {rel_error:.1f} %")
        print(f"Clinical Agreement:      [{agreement}]")
    else:
        print("Reference BPM:           Not provided")

    print("=" * 70 + "\n")

    # Plot 4-panel visualization
    fig, axes = plt.subplots(4, 1, figsize=(12, 13))

    # Panel 1: RGB intensity over time
    axes[0].plot(timestamps, rgb[:, 0], label="Red Channel", color="#d32f2f", alpha=0.9)
    axes[0].plot(timestamps, rgb[:, 1], label="Green Channel", color="#2e7d32", alpha=0.9)
    axes[0].plot(timestamps, rgb[:, 2], label="Blue Channel", color="#1565c0", alpha=0.9)
    axes[0].set_title(f"Mean ROI Color Intensity Over Time ({backend_name})", fontsize=11, fontweight="bold")
    axes[0].set_xlabel("Time (seconds)")
    axes[0].set_ylabel("Intensity")
    axes[0].legend(loc="upper right")
    axes[0].grid(True, linestyle="--", alpha=0.6)

    # Panel 2: Synchronous Multi-Patch Filtered Waveforms
    axes[1].plot(timestamps, filtered_fh, label="Forehead Pulse", color="#00838f", linewidth=1.5, alpha=0.9)
    axes[1].plot(timestamps, filtered_lc, label="Left Cheek Pulse", color="#2e7d32", linewidth=1.5, alpha=0.9)
    axes[1].plot(timestamps, filtered_rc, label="Right Cheek Pulse", color="#7b1fa2", linewidth=1.5, alpha=0.9)
    axes[1].set_title(
        f"Multi-Region rPPG Pulsatile Waveforms (Spatial Correlation: {liveness['mean_correlation']:+.2f})",
        fontsize=11,
        fontweight="bold",
    )
    axes[1].set_xlabel("Time (seconds)")
    axes[1].set_ylabel("Amplitude")
    axes[1].legend(loc="upper right")
    axes[1].grid(True, linestyle="--", alpha=0.6)

    # Panel 3: Pulse frequency spectrum
    in_band_bpm = frequencies * 60.0
    axes[2].plot(in_band_bpm, power, color="#6a1b9a", linewidth=1.8, label="Power Spectrum (Welch PSD)")
    axes[2].axvline(effective_bpm, linestyle="--", color="#c62828", linewidth=2.0, label=f"Estimated: {effective_bpm:.1f} BPM")

    if has_ref:
        axes[2].axvline(
            reference_bpm,
            linestyle="-.",
            color="#2e7d32",
            linewidth=2.0,
            label=f"Reference: {reference_bpm:.1f} BPM (Error: {abs_error:.1f})",
        )

    axes[2].set_xlim(MIN_BPM, MAX_BPM)
    axes[2].set_title(
        f"Pulse Frequency Spectrum | SQI: {quality_rating.split(' ')[0]} (SNR: {snr_db:.1f} dB)",
        fontsize=11,
        fontweight="bold",
    )
    axes[2].set_xlabel("Frequency (BPM)")
    axes[2].set_ylabel("Power")
    axes[2].legend(loc="upper right")
    axes[2].grid(True, linestyle="--", alpha=0.6)

    # Panel 4: Cross-Region Spectral Coherence
    for pair_name, (c_freqs, c_xy) in liveness["coherence_curves"].items():
        if len(c_freqs) > 0:
            axes[3].plot(c_freqs * 60.0, c_xy, linewidth=1.6, label=pair_name)
    axes[3].axhline(0.50, color="#d32f2f", linestyle=":", linewidth=1.5, label="Authenticity Threshold (0.50)")
    axes[3].set_xlim(MIN_BPM, MAX_BPM)
    axes[3].set_ylim(0.0, 1.05)
    axes[3].set_title(
        f"Inter-Patch Spectral Coherence Cxy(f) | Verdict: {liveness['verdict']} (Mean: {liveness['mean_coherence']:.2f})",
        fontsize=11,
        fontweight="bold",
    )
    axes[3].set_xlabel("Frequency (BPM)")
    axes[3].set_ylabel("Coherence (0 - 1)")
    axes[3].legend(loc="upper right")
    axes[3].grid(True, linestyle="--", alpha=0.6)

    plt.tight_layout()

    if save_plot:
        plt.savefig(save_plot, dpi=150)
        print(f"Spectrum & coherence plot saved to: {save_plot}")

    # Log to CSV
    if log_file:
        record = {
            "Timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "Video_File": os.path.basename(video_path),
            "Liveness_Verdict": liveness["verdict"],
            "Spatial_Coherence": f"{liveness['mean_coherence']:.3f}",
            "Mean_Correlation": f"{liveness['mean_correlation']:.3f}",
            "Freq_Spread_BPM": f"{liveness['max_freq_discrepancy']:.1f}",
            "Duration_s": f"{duration:.2f}",
            "Nominal_FPS": f"{fps:.2f}",
            "Actual_Sampling_Rate": f"{actual_sampling_rate:.2f}",
            "Face_Patch_Pct": f"{face_ratio * 100:.1f}",
            "Max_Gap_s": f"{max_gap_sec:.2f}",
            "Estimated_BPM": f"{effective_bpm:.1f}",
            "Reference_BPM": f"{reference_bpm:.1f}" if has_ref else "N/A",
            "Abs_Error_BPM": f"{abs_error:.1f}" if has_ref else "N/A",
            "Rel_Error_Pct": f"{rel_error:.1f}" if has_ref else "N/A",
            "Peak_Power_Fraction": f"{peak_fraction:.3f}",
            "SNR_dB": f"{snr_db:.1f}",
            "Quality_Rating": quality_rating,
            "Detector_Backend": detector.backend,
        }
        log_validation_result(log_file, record)

    if show_plot:
        try:
            plt.show()
        except Exception as e:
            print(f"Could not open GUI plot window: {e}")
    else:
        plt.close(fig)

    return {
        "bpm": effective_bpm,
        "reference_bpm": reference_bpm,
        "abs_error": abs_error,
        "rel_error": rel_error,
        "agreement": agreement,
        "duration": duration,
        "fps": fps,
        "actual_sampling_rate": actual_sampling_rate,
        "face_ratio": face_ratio,
        "max_gap_sec": max_gap_sec,
        "peak_fraction": peak_fraction,
        "snr_db": snr_db,
        "quality_rating": quality_rating,
        "warnings": quality_warnings,
        "liveness_verdict": liveness["verdict"],
        "liveness_title": liveness["verdict_title"],
        "liveness_description": liveness["verdict_description"],
        "is_real": liveness["is_real"],
        "is_spoof": liveness.get("is_spoof", False),
        "spoof_type": liveness.get("spoof_type"),
        "screen_cues": screen_cues,
        "mean_correlation": liveness["mean_correlation"],
        "mean_coherence": liveness["mean_coherence"],
        "max_freq_discrepancy": liveness["max_freq_discrepancy"],
        "pairwise_correlations": liveness["pairwise_correlations"],
    }


# ---------------- CLI ENTRYPOINT ----------------

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Extract and validate an rPPG pulse estimate from a face video."
    )
    parser.add_argument(
        "video",
        nargs="?",
        default=None,
        help="Path to the input face video (default: videos/my_face.mp4 if present)",
    )
    parser.add_argument(
        "--reference-bpm",
        "--ref-bpm",
        type=float,
        default=None,
        help="Ground-truth reference pulse rate (from a pulse oximeter or monitor) for validation error calculation",
    )
    parser.add_argument(
        "--detector",
        choices=["auto", "mediapipe", "opencv"],
        default="auto",
        help="Face detector backend: 'auto' (preferred MediaPipe landmarks), 'mediapipe', or 'opencv' (default: auto)",
    )
    parser.add_argument(
        "--save-plot",
        type=str,
        default="rppg_plot.png",
        help="Path to save output spectrum plot image (default: rppg_plot.png, set to '' to disable)",
    )
    parser.add_argument(
        "--no-show",
        action="store_true",
        help="Disable interactive GUI plot display (useful for scripts, benchmarks, or headless testing)",
    )
    parser.add_argument(
        "--max-gap",
        type=float,
        default=DEFAULT_MAX_GAP_SEC,
        help=f"Maximum acceptable consecutive tracking gap in seconds before warning (default: {DEFAULT_MAX_GAP_SEC}s)",
    )
    parser.add_argument(
        "--log-file",
        type=str,
        default="validation_log.csv",
        help="CSV log file path to record validation metrics across multiple recordings (default: validation_log.csv)",
    )
    parser.add_argument(
        "--record",
        nargs="?",
        const=35,
        type=int,
        help="Record a new video using webcam (optional duration in seconds, default 35s)",
    )
    args = parser.parse_args()

    # Handle webcam recording request
    if args.record is not None:
        try:
            import record_video
            recorded_path = record_video.record_webcam(duration_sec=args.record)
            if recorded_path and os.path.exists(recorded_path):
                args.video = recorded_path
            else:
                sys.exit(0)
        except ImportError:
            print("record_video.py module not found. Run recording separately.")
            sys.exit(1)

    video_path = args.video
    if not video_path:
        default_candidate = os.path.join(
            os.path.dirname(os.path.abspath(__file__)), "videos", "my_face.mp4"
        )
        if os.path.exists(default_candidate):
            video_path = default_candidate
            print(f"No video argument supplied. Using sample video: {video_path}")
        else:
            parser.error("No input video specified and default video 'videos/my_face.mp4' not found.")

    if not os.path.exists(video_path):
        print(f"Error: Video file not found: {video_path}")
        sys.exit(1)

    try:
        save_path = args.save_plot if args.save_plot else None
        log_path = args.log_file if args.log_file else None
        process_video(
            video_path,
            reference_bpm=args.reference_bpm,
            detector_mode=args.detector,
            save_plot=save_path,
            show_plot=not args.no_show,
            max_gap_threshold=args.max_gap,
            log_file=log_path,
        )
    except (ValueError, RuntimeError) as error:
        print(f"\nProcessing failed: {error}")
        sys.exit(1)
