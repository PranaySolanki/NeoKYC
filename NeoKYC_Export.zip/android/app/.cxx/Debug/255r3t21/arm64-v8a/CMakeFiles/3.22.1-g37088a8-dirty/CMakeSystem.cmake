set(CMAKE_HOST_SYSTEM "Windows-10.0.26300")
set(CMAKE_HOST_SYSTEM_NAME "Windows")
set(CMAKE_HOST_SYSTEM_VERSION "10.0.26300")
set(CMAKE_HOST_SYSTEM_PROCESSOR "AMD64")

include("C:/Users/Admin/AppData/Local/Android/Sdk/ndk/27.1.12297006/build/cmake/android.toolchain.cmake")

set(CMAKE_SYSTEM "Android-1")
set(CMAKE_SYSTEM_NAME "Android")
set(CMAKE_SYSTEM_VERSION "1")
set(CMAKE_SYSTEM_PROCESSOR "aarch64")

set(CMAKE_CROSSCOMPILING "TRUE")

set(CMAKE_SYSTEM_LOADED 1)
