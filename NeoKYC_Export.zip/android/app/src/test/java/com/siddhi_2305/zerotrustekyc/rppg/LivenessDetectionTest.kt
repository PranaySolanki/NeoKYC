package com.siddhi_2305.zerotrustekyc.rppg

import org.junit.Assert.*
import org.junit.Test
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

class LivenessDetectionTest {

    @Test
    fun testDsp_EstimateBpm_SyntheticCardiacSignal() {
        val fps = 30.0
        val targetBpm = 75.0 // 1.25 Hz
        val targetFreq = targetBpm / 60.0
        val numFrames = 210 // 7.0 seconds

        val rawSignal = DoubleArray(numFrames)
        for (i in 0 until numFrames) {
            val t = i / fps
            // Clean synthetic cardiac pulse at 75 BPM with harmonic
            val cardiac = sin(2.0 * PI * targetFreq * t)
            val harmonic = 0.3 * sin(4.0 * PI * targetFreq * t)
            rawSignal[i] = 120.0 + 5.0 * (cardiac + harmonic)
        }

        // Apply bandpass filter to simulate rPPG pipeline
        val filtered = DspUtils.bandpassFilter(rawSignal, fps)
        val result = DspUtils.estimateBpmAndQuality(filtered, fps)

        // Estimated BPM should be close to 75.0 (+/- 5 BPM resolution limit for 7s window)
        assertTrue("Estimated BPM was ${result.bpm}, expected ~75", result.bpm in 70.0..80.0)
        assertTrue("SNR should be positive for synthetic pulse, was ${result.snrDb}", result.snrDb > 3.0)
        assertTrue("Peak power fraction should be substantial, was ${result.peakPowerFraction}", result.peakPowerFraction > 0.15)
    }

    @Test
    fun testDsp_EstimateBpm_FlatStaticSignal() {
        val fps = 30.0
        val numFrames = 210
        val flatSignal = DoubleArray(numFrames) { 128.0 } // Zero AC pulsation (static image)

        val result = DspUtils.estimateBpmAndQuality(flatSignal, fps)

        assertEquals("Flat signal should yield 0 BPM", 0.0, result.bpm, 0.001)
        assertEquals("Flat signal should yield 0 SNR", 0.0, result.snrDb, 0.001)
        assertEquals("Flat signal should yield 0 peak power fraction", 0.0, result.peakPowerFraction, 0.001)
    }

    @Test
    fun testDsp_BandpassFilter_PreservesCardiacRange() {
        val fps = 30.0
        val numFrames = 256
        val signal = DoubleArray(numFrames) { i ->
            val t = i / fps
            sin(2.0 * PI * 1.2 * t) // 1.2 Hz = 72 BPM
        }

        val filtered = DspUtils.bandpassFilter(signal, fps)
        assertEquals(numFrames, filtered.size)

        // Energy should be preserved
        var energy = 0.0
        for (v in filtered) {
            energy += v * v
        }
        assertTrue("Filtered cardiac signal should have positive energy", energy > 1.0)
    }

    @Test
    fun testDsp_Detrend_RemovesLinearDrift() {
        val n = 128
        val drifting = DoubleArray(n) { i -> 100.0 + 2.5 * i } // Strong baseline drift
        val detrended = DspUtils.detrend(drifting)

        val mean = detrended.average()
        assertEquals("Detrended signal should have zero mean", 0.0, mean, 1e-6)
    }

    @Test
    fun testVerdictEngine_StaticPhotoSpoof() {
        // Simulates the static photo detection criteria implemented in RppgProcessor
        val challengesPassed = false
        val earVariance = 0.0008f   // Completely frozen eyes
        val smileVariance = 0.0006f // Completely frozen mouth
        val hasPulse = false
        val faceRatio = 0.95f       // Face clearly visible and static

        val isStaticPhotoSpoof = (!challengesPassed && earVariance < 0.0035f && smileVariance < 0.0025f && !hasPulse)
        assertTrue("Should detect static photo spoof", isStaticPhotoSpoof)

        val verdict = if (isStaticPhotoSpoof) "SPOOF_DETECTED" else "UNKNOWN"
        assertEquals("SPOOF_DETECTED", verdict)
    }

    @Test
    fun testVerdictEngine_PhysicalMaskDetection() {
        // Simulates mask detection via aberrant skin chrominance + absence of pulse
        val redRatio = 0.85 // Normal skin has R > G > B, Red usually dominates over 1.2x
        val blueRatio = 1.10 // Mask with unnatural blue/green reflection
        val hasPulse = false
        val challengesPassed = false

        val isAbnormalChrominance = (redRatio < 1.05 || blueRatio > 0.95)
        val isMaskSpoof = isAbnormalChrominance && !hasPulse && !challengesPassed

        assertTrue("Should detect physical mask spoof via chrominance and lack of pulse", isMaskSpoof)
    }

    @Test
    fun testVerdictEngine_NeverMarkRealPersonAsSpoofOnFailure() {
        // Case: user looked away or lighting dropped, lost face tracking (faceRatio < 0.45)
        val faceRatio = 0.30f
        val challengesPassed = false

        val isTrackingFailure = faceRatio < 0.45f
        val verdict = if (isTrackingFailure) "VERIFICATION_FAILED" else "UNKNOWN"

        assertEquals("Technical/tracking drop must be VERIFICATION_FAILED, NEVER SPOOF", "VERIFICATION_FAILED", verdict)
    }

    @Test
    fun testVerdictEngine_InconclusiveWhenGesturesPassButPulseNoisy() {
        // Case: genuine human moved their head during the still window, corrupting pulse
        val challengesPassed = true
        val faceRatio = 0.88f
        val pulseReliable = false
        val isConfirmedSpoof = false

        val verdict = when {
            isConfirmedSpoof -> "SPOOF_DETECTED"
            !challengesPassed -> "VERIFICATION_FAILED"
            pulseReliable -> "REAL_FACE_VERIFIED"
            else -> "INCONCLUSIVE"
        }

        assertEquals("Noisy pulse on passed gestures must be INCONCLUSIVE, NEVER SPOOF", "INCONCLUSIVE", verdict)
    }

    @Test
    fun testVerdictEngine_RealFaceVerifiedWhenAllCriteriaMet() {
        // Case: gestures passed, living face dynamics present, valid rPPG pulse
        val challengesPassed = true
        val faceRatio = 0.92f
        val earVariance = 0.012f
        val smileVariance = 0.008f
        val pulseReliable = true
        val isConfirmedSpoof = false

        val verdict = when {
            isConfirmedSpoof -> "SPOOF_DETECTED"
            !challengesPassed -> "VERIFICATION_FAILED"
            pulseReliable && earVariance > 0.0035f -> "REAL_FACE_VERIFIED"
            else -> "INCONCLUSIVE"
        }

        assertEquals("REAL_FACE_VERIFIED", verdict)
    }

    @Test
    fun testDsp_ComputeMultiPatchCoherence_SynchronousRealPulse() {
        val fps = 15.0
        val targetBpm = 72.0 // 1.20 Hz
        val targetFreq = targetBpm / 60.0
        val numFrames = 120 // 8.0 seconds

        // Simulate 3 anatomical regions: Forehead, Left Cheek, Right Cheek
        // Real pulse: Forehead, Left Cheek, and Right Cheek oscillate at the same frequency
        // with small physiological pulse transit time (small phase offset < 0.05s)
        val foreheadRgb = ArrayList<DoubleArray>()
        val leftCheekRgb = ArrayList<DoubleArray>()
        val rightCheekRgb = ArrayList<DoubleArray>()

        for (i in 0 until numFrames) {
            val t = i / fps
            val pulseFh = sin(2.0 * PI * targetFreq * t)
            val pulseLc = sin(2.0 * PI * targetFreq * (t - 0.02)) // slight arterial delay
            val pulseRc = sin(2.0 * PI * targetFreq * (t - 0.02))

            // In POS, green channel fluctuates with pulsatile absorption
            foreheadRgb.add(doubleArrayOf(150.0, 120.0 + 3.0 * pulseFh, 110.0))
            leftCheekRgb.add(doubleArrayOf(152.0, 122.0 + 3.2 * pulseLc, 111.0))
            rightCheekRgb.add(doubleArrayOf(149.0, 119.0 + 3.1 * pulseRc, 109.0))
        }

        val patchMap = mapOf(
            "FOREHEAD" to foreheadRgb,
            "LEFT_CHEEK" to leftCheekRgb,
            "RIGHT_CHEEK" to rightCheekRgb
        )

        val coherenceResult = DspUtils.evaluateMultiPatchCoherence(patchMap, fps)

        assertTrue("Consensus BPM should be close to 72 BPM, was ${coherenceResult.consensusBpm}",
            coherenceResult.consensusBpm in 67.0..77.0)
        assertTrue("Mean correlation should be high for synchronous pulses (>0.60), was ${coherenceResult.meanCoherence}",
            coherenceResult.meanCoherence > 0.60)
        assertTrue("Frequency discrepancy should be low (<6 BPM), was ${coherenceResult.maxFreqDiscrepancyBpm}",
            coherenceResult.maxFreqDiscrepancyBpm <= 6.0)
        assertTrue("Should be marked as physiologically coherent", coherenceResult.isCoherent)
        assertFalse("Real synchronized pulse should NOT be flagged as deepfake", coherenceResult.isDeepfakeSuspect)
    }

    @Test
    fun testDsp_ComputeMultiPatchCoherence_DiscordantDeepfakeOrSyntheticNoise() {
        val fps = 15.0
        val numFrames = 120 // 8.0 seconds

        // Simulate Deepfake / AI Face-Swap:
        // Forehead has frequency 65 BPM, left cheek has frequency 115 BPM, right cheek has uncorrelated noise
        val foreheadRgb = ArrayList<DoubleArray>()
        val leftCheekRgb = ArrayList<DoubleArray>()
        val rightCheekRgb = ArrayList<DoubleArray>()

        for (i in 0 until numFrames) {
            val t = i / fps
            val waveFh = sin(2.0 * PI * (65.0 / 60.0) * t)
            val waveLc = sin(2.0 * PI * (115.0 / 60.0) * t) // discordant frequency
            val waveRc = sin(2.0 * PI * 2.8 * t) * cos(2.0 * PI * 0.4 * t) // synthetic artifact

            foreheadRgb.add(doubleArrayOf(145.0, 118.0 + 2.5 * waveFh, 105.0))
            leftCheekRgb.add(doubleArrayOf(148.0, 120.0 + 2.8 * waveLc, 108.0))
            rightCheekRgb.add(doubleArrayOf(142.0, 115.0 + 3.0 * waveRc, 102.0))
        }

        val patchMap = mapOf(
            "FOREHEAD" to foreheadRgb,
            "LEFT_CHEEK" to leftCheekRgb,
            "RIGHT_CHEEK" to rightCheekRgb
        )

        val coherenceResult = DspUtils.evaluateMultiPatchCoherence(patchMap, fps)

        assertTrue("Frequency discrepancy should be large (>10 BPM) for deepfake/synthetic face, was ${coherenceResult.maxFreqDiscrepancyBpm}",
            coherenceResult.maxFreqDiscrepancyBpm > 10.0 || coherenceResult.meanCoherence < 0.40)
        assertFalse("Discordant patches should NOT be marked coherent", coherenceResult.isCoherent)
        assertTrue("Should be flagged as deepfake suspect due to spatial pulse discordance", coherenceResult.isDeepfakeSuspect)
    }

    @Test
    fun testVerdictEngine_DeepfakePulseIncoherenceTriggersSpoof() {
        // Case: User / AI video completed gesture challenges, but rPPG patches are discordant (Deepfake)
        val challengesPassed = true
        val faceRatio = 0.90f
        val earVariance = 0.015f
        val isDeepfakeSuspect = true
        val isCoherentPulse = false

        val isConfirmedSpoof = isDeepfakeSuspect

        val verdict = when {
            isConfirmedSpoof -> "SPOOF_DETECTED"
            !challengesPassed -> "VERIFICATION_FAILED"
            isCoherentPulse && earVariance > 0.0035f -> "REAL_FACE_VERIFIED"
            else -> "INCONCLUSIVE"
        }

        assertEquals("SPOOF_DETECTED", verdict)
    }

    @Test
    fun testDsp_ComputeMultiPatchCoherence_RealHumanWithAmbientShadowsNotDeepfake() {
        val fps = 15.0
        val numFrames = 120

        // Simulate real human under uneven room lighting:
        // Forehead and Cheeks have the SAME pulse frequency (72 BPM), but cheek has lower amplitude / shadow
        val foreheadRgb = ArrayList<DoubleArray>()
        val leftCheekRgb = ArrayList<DoubleArray>()
        val rightCheekRgb = ArrayList<DoubleArray>()

        for (i in 0 until numFrames) {
            val t = i / fps
            val cardiac = sin(2.0 * PI * (72.0 / 60.0) * t)

            foreheadRgb.add(doubleArrayOf(150.0, 120.0 + 2.0 * cardiac, 110.0))
            leftCheekRgb.add(doubleArrayOf(145.0, 115.0 + 1.2 * cardiac, 105.0))
            // Right cheek is in slight shadow with ambient noise
            rightCheekRgb.add(doubleArrayOf(135.0, 105.0 + 0.8 * cardiac, 95.0))
        }

        val patchMap = mapOf(
            "FOREHEAD" to foreheadRgb,
            "LEFT_CHEEK" to leftCheekRgb,
            "RIGHT_CHEEK" to rightCheekRgb
        )

        val coherenceResult = DspUtils.evaluateMultiPatchCoherence(patchMap, fps)

        // Frequencies are matched because it's a real pulse from the same heart
        assertEquals("Frequencies across patches should agree", 0.0, coherenceResult.maxFreqDiscrepancyBpm, 4.0)
        assertFalse("Real human under uneven lighting must NOT be flagged as deepfake", coherenceResult.isDeepfakeSuspect)
    }

    @Test
    fun testDsp_EstimateBpm_PureNoiseRejectedByTemporalConsistency() {
        val fps = 15.0
        val numFrames = 120
        val rnd = java.util.Random(42)

        var inconsistentCount = 0
        val trials = 20
        for (t in 0 until trials) {
            val noise = DoubleArray(numFrames) { rnd.nextGaussian() }
            val filtered = DspUtils.bandpassFilter(noise, fps)
            val consistency = DspUtils.checkTemporalConsistency(filtered, fps)
            if (!consistency.isConsistent) {
                inconsistentCount++
            }
        }
        // At least 80% of pure noise trials must fail temporal consistency
        assertTrue("Pure noise should fail temporal consistency in most trials, failed $inconsistentCount / $trials",
            inconsistentCount >= 16)
    }

    @Test
    fun testDsp_ComputeMultiPatchCoherence_CommonModeNoiseRejected() {
        val fps = 15.0
        val numFrames = 120
        val rnd = java.util.Random(1234)

        // Common-mode noise across all patches (e.g. ambient flicker / phone AGC)
        val foreheadRgb = ArrayList<DoubleArray>()
        val leftCheekRgb = ArrayList<DoubleArray>()
        val rightCheekRgb = ArrayList<DoubleArray>()

        for (i in 0 until numFrames) {
            val common = rnd.nextGaussian() * 2.0
            foreheadRgb.add(doubleArrayOf(140.0, 110.0 + common + rnd.nextGaussian() * 0.2, 100.0))
            leftCheekRgb.add(doubleArrayOf(142.0, 112.0 + common + rnd.nextGaussian() * 0.2, 101.0))
            rightCheekRgb.add(doubleArrayOf(139.0, 109.0 + common + rnd.nextGaussian() * 0.2, 99.0))
        }

        val patchMap = mapOf(
            "FOREHEAD" to foreheadRgb,
            "LEFT_CHEEK" to leftCheekRgb,
            "RIGHT_CHEEK" to rightCheekRgb
        )

        val coherenceResult = DspUtils.evaluateMultiPatchCoherence(patchMap, fps)

        // Common-mode noise without legitimate physiological pulse must NOT be declared coherent
        assertFalse("Common-mode noise must NOT be marked as a coherent biological pulse", coherenceResult.isCoherent)
    }

    @Test
    fun testChallenge_DirectionalHeadTurnLogic() {
        // TURN_LEFT: baseline yaw = 0.0, turning left produces positive yaw (maxYaw - baseline >= 0.035)
        val leftTurnYawSamples = listOf(0.00, 0.01, 0.00, 0.02, 0.05, 0.06, 0.03)
        val baselineLeft = leftTurnYawSamples.take(3).average()
        val maxYaw = leftTurnYawSamples.maxOrNull() ?: 0.0
        val leftVerified = (maxYaw - baselineLeft) >= 0.035
        assertTrue("Turning left when challenged to TURN_LEFT should pass", leftVerified)

        // Wrong direction: user turned right when challenged to TURN_LEFT (yaw becomes negative)
        val rightTurnWhenLeftChallenged = listOf(0.00, 0.00, -0.01, -0.03, -0.05, -0.06)
        val baselineWrong = rightTurnWhenLeftChallenged.take(3).average()
        val maxWrongYaw = rightTurnWhenLeftChallenged.maxOrNull() ?: 0.0
        val wrongLeftVerified = (maxWrongYaw - baselineWrong) >= 0.035
        assertFalse("Turning right when challenged to TURN_LEFT must FAIL", wrongLeftVerified)

        // TURN_RIGHT: baseline yaw = 0.0, turning right produces negative yaw (baseline - minYaw >= 0.035)
        val rightTurnYawSamples = listOf(0.00, -0.01, 0.00, -0.02, -0.05, -0.06, -0.03)
        val baselineRight = rightTurnYawSamples.take(3).average()
        val minYaw = rightTurnYawSamples.minOrNull() ?: 0.0
        val rightVerified = (baselineRight - minYaw) >= 0.035
        assertTrue("Turning right when challenged to TURN_RIGHT should pass", rightVerified)

        // Wrong direction: user turned left when challenged to TURN_RIGHT (yaw becomes positive)
        val leftTurnWhenRightChallenged = listOf(0.00, 0.01, 0.00, 0.03, 0.05, 0.06)
        val baselineWrongRight = leftTurnWhenRightChallenged.take(3).average()
        val minWrongYaw = leftTurnWhenRightChallenged.minOrNull() ?: 0.0
        val wrongRightVerified = (baselineWrongRight - minWrongYaw) >= 0.035
        assertFalse("Turning left when challenged to TURN_RIGHT must FAIL", wrongRightVerified)
    }
}
