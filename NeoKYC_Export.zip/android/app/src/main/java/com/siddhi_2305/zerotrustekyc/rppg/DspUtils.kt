package com.siddhi_2305.zerotrustekyc.rppg

import kotlin.math.*

/**
 * Digital Signal Processing utilities for on-device rPPG pulse estimation:
 * - Cooley-Tukey Radix-2 FFT and Inverse FFT
 * - Least-squares polynomial baseline detrending
 * - Zero-phase frequency-domain Bandpass Filtering (42 - 180 BPM)
 * - POS (Plane-Orthogonal-to-Skin) chrominance projection algorithm
 * - Welch Power Spectral Density (PSD) estimation & Signal-to-Noise Ratio (SNR)
 */
object DspUtils {

    const val MIN_BPM = 42.0
    const val MAX_BPM = 180.0
    const val WINDOW_SECONDS = 1.6
    const val CARDIAC_HALF_BAND_HZ = 0.24 // Captures full fundamental Hann main lobe (1/T = 0.222 Hz for 4.5s segment) without harmonic

    data class PsdResult(
        val frequencies: DoubleArray,
        val power: DoubleArray,
        val peakHz: Double,
        val bpm: Double,
        val peakPowerFraction: Double,
        val snrDb: Double
    )

    /**
     * POS (Plane-Orthogonal-to-Skin) rPPG extraction algorithm
     * Based on Wang et al., IEEE TBME 2017: "Algorithmic Principles of Remote PPG"
     *
     * @param rgb Array of [R, G, B] values for each temporal frame
     * @param fps Effective sampling rate in frames per second
     * @return Raw extracted pulsatile signal of length rgb.size
     */
    fun posSignal(rgb: List<DoubleArray>, fps: Double, windowSec: Double = WINDOW_SECONDS): DoubleArray {
        val count = rgb.size
        val window = max(8, (windowSec * fps).roundToInt())
        val output = DoubleArray(count)
        val weights = DoubleArray(count)

        if (count < window) {
            // Signal shorter than sliding window: process as single segment
            return singleSegmentPos(rgb)
        }

        for (start in 0..(count - window)) {
            val end = start + window

            // 1. Temporal mean of current segment
            var meanR = 0.0
            var meanG = 0.0
            var meanB = 0.0
            for (i in start until end) {
                meanR += rgb[i][0]
                meanG += rgb[i][1]
                meanB += rgb[i][2]
            }
            meanR /= window
            meanG /= window
            meanB /= window

            if (meanR < 1e-6 || meanG < 1e-6 || meanB < 1e-6) {
                continue
            }

            // 2. Temporal normalization & projection to S1, S2
            val s1 = DoubleArray(window)
            val s2 = DoubleArray(window)
            var sumS1 = 0.0
            var sumS2 = 0.0

            for (i in 0 until window) {
                val idx = start + i
                val rNorm = rgb[idx][0] / meanR
                val gNorm = rgb[idx][1] / meanG
                val bNorm = rgb[idx][2] / meanB

                s1[i] = gNorm - bNorm
                s2[i] = gNorm + bNorm - 2.0 * rNorm
                sumS1 += s1[i]
                sumS2 += s2[i]
            }

            // 3. Compute standard deviations
            val avgS1 = sumS1 / window
            val avgS2 = sumS2 / window
            var varS1 = 0.0
            var varS2 = 0.0
            for (i in 0 until window) {
                val diff1 = s1[i] - avgS1
                val diff2 = s2[i] - avgS2
                varS1 += diff1 * diff1
                varS2 += diff2 * diff2
            }
            val std1 = sqrt(varS1 / window)
            val std2 = sqrt(varS2 / window)

            if (std2 < 1e-8) {
                continue
            }

            // 4. Alpha tuning factor
            val alpha = std1 / std2

            // 5. Combine and remove segment mean
            var sumH = 0.0
            val h = DoubleArray(window)
            for (i in 0 until window) {
                h[i] = s1[i] + alpha * s2[i]
                sumH += h[i]
            }
            val avgH = sumH / window

            // 6. Overlap-add
            for (i in 0 until window) {
                val target = start + i
                output[target] += (h[i] - avgH)
                weights[target] += 1.0
            }
        }

        // Normalize by overlap weights
        for (i in 0 until count) {
            if (weights[i] > 0.0) {
                output[i] /= weights[i]
            }
        }

        return output
    }

    private fun singleSegmentPos(rgb: List<DoubleArray>): DoubleArray {
        val count = rgb.size
        var meanR = 0.0; var meanG = 0.0; var meanB = 0.0
        for (item in rgb) {
            meanR += item[0]; meanG += item[1]; meanB += item[2]
        }
        meanR = max(1e-6, meanR / count)
        meanG = max(1e-6, meanG / count)
        meanB = max(1e-6, meanB / count)

        val s1 = DoubleArray(count)
        val s2 = DoubleArray(count)
        var sumS1 = 0.0; var sumS2 = 0.0
        for (i in 0 until count) {
            val rNorm = rgb[i][0] / meanR
            val gNorm = rgb[i][1] / meanG
            val bNorm = rgb[i][2] / meanB
            s1[i] = gNorm - bNorm
            s2[i] = gNorm + bNorm - 2.0 * rNorm
            sumS1 += s1[i]; sumS2 += s2[i]
        }
        val avgS1 = sumS1 / count
        val avgS2 = sumS2 / count
        var varS1 = 0.0; var varS2 = 0.0
        for (i in 0 until count) {
            varS1 += (s1[i] - avgS1) * (s1[i] - avgS1)
            varS2 += (s2[i] - avgS2) * (s2[i] - avgS2)
        }
        val alpha = if (varS2 > 1e-12) sqrt(varS1 / varS2) else 1.0
        val out = DoubleArray(count)
        var sumOut = 0.0
        for (i in 0 until count) {
            out[i] = s1[i] + alpha * s2[i]
            sumOut += out[i]
        }
        val avgOut = sumOut / count
        for (i in 0 until count) {
            out[i] -= avgOut
        }
        return out
    }

    /**
     * Least-squares linear detrending: y[n] - (beta0 + beta1 * n)
     */
    fun detrend(signal: DoubleArray): DoubleArray {
        val n = signal.size
        if (n < 2) return signal.clone()

        var sumX = 0.0
        var sumY = 0.0
        var sumXX = 0.0
        var sumXY = 0.0

        for (i in 0 until n) {
            val x = i.toDouble()
            val y = signal[i]
            sumX += x
            sumY += y
            sumXX += x * x
            sumXY += x * y
        }

        val denominator = n * sumXX - sumX * sumX
        if (abs(denominator) < 1e-12) return signal.clone()

        val slope = (n * sumXY - sumX * sumY) / denominator
        val intercept = (sumY - slope * sumX) / n

        val detrended = DoubleArray(n)
        for (i in 0 until n) {
            detrended[i] = signal[i] - (intercept + slope * i)
        }
        return detrended
    }

    /**
     * Zero-phase frequency-domain bandpass filter in cardiac pulse band [minHz, maxHz]
     * Includes smooth cosine taper on transition edges to prevent Gibbs ringing.
     */
    fun bandpassFilter(signal: DoubleArray, fps: Double, minBpm: Double = MIN_BPM, maxBpm: Double = MAX_BPM): DoubleArray {
        val n = signal.size
        if (n < 8) return signal.clone()

        val detrended = detrend(signal)
        val fftSize = nextPowerOf2(n)

        val real = DoubleArray(fftSize)
        val imag = DoubleArray(fftSize)
        System.arraycopy(detrended, 0, real, 0, n)

        // Apply 5% Tukey taper to signal edges to avoid FFT edge leakage
        val taperLen = max(2, (n * 0.05).toInt())
        for (i in 0 until taperLen) {
            val w = 0.5 * (1.0 - cos(PI * i / taperLen))
            real[i] *= w
            real[n - 1 - i] *= w
        }

        fft(real, imag)

        val minHz = minBpm / 60.0
        val maxHz = min(maxBpm / 60.0, fps * 0.48)
        val transHz = 0.10 // 0.10 Hz transition band

        for (k in 0..(fftSize / 2)) {
            val freq = k * fps / fftSize
            var gain = 0.0

            if (freq in minHz..maxHz) {
                gain = 1.0
            } else if (freq in (minHz - transHz)..minHz) {
                // Low transition taper
                gain = 0.5 * (1.0 + cos(PI * (minHz - freq) / transHz))
            } else if (freq in maxHz..(maxHz + transHz)) {
                // High transition taper
                gain = 0.5 * (1.0 + cos(PI * (freq - maxHz) / transHz))
            }

            real[k] *= gain
            imag[k] *= gain

            if (k > 0 && k < fftSize / 2) {
                val mirror = fftSize - k
                real[mirror] *= gain
                imag[mirror] *= gain
            }
        }

        ifft(real, imag)

        val filtered = DoubleArray(n)
        System.arraycopy(real, 0, filtered, 0, n)
        return filtered
    }

    /**
     * Welch Power Spectral Density (PSD) estimation & Signal-to-Noise Ratio (SNR)
     */
    fun estimateBpmAndQuality(signal: DoubleArray, fps: Double): PsdResult {
        val n = signal.size
        if (n < 16) {
            return PsdResult(DoubleArray(0), DoubleArray(0), 0.0, 0.0, 0.0, 0.0)
        }

        // Segment size: min(n, 4.5 * fps), at least 32 points for true Welch multi-window averaging
        val segLen = min(n, max(32, (4.5 * fps).roundToInt()))
        val step = max(1, segLen / 2) // 50% overlap
        val nFft = max(1024, nextPowerOf2(segLen * 4)) // High frequency resolution

        val numFreqBins = nFft / 2 + 1
        val avgPower = DoubleArray(numFreqBins)
        val freqs = DoubleArray(numFreqBins) { k -> k * fps / nFft }

        // Precompute Hann window
        val hann = DoubleArray(segLen)
        var hannSumSq = 0.0
        for (i in 0 until segLen) {
            hann[i] = 0.5 * (1.0 - cos(2.0 * PI * i / (segLen - 1)))
            hannSumSq += hann[i] * hann[i]
        }
        if (hannSumSq < 1e-12) hannSumSq = 1.0

        var segmentsCount = 0
        var segStart = 0

        while (segStart + segLen <= n) {
            val real = DoubleArray(nFft)
            val imag = DoubleArray(nFft)

            var segMean = 0.0
            for (i in 0 until segLen) {
                segMean += signal[segStart + i]
            }
            segMean /= segLen

            for (i in 0 until segLen) {
                real[i] = (signal[segStart + i] - segMean) * hann[i]
            }

            fft(real, imag)

            for (k in 0 until numFreqBins) {
                val p = (real[k] * real[k] + imag[k] * imag[k]) / (fps * hannSumSq)
                avgPower[k] += p
            }

            segmentsCount++
            segStart += step
        }

        // If no full segments fit, do a single window on full length
        if (segmentsCount == 0) {
            val real = DoubleArray(nFft)
            val imag = DoubleArray(nFft)
            val mean = signal.average()
            for (i in 0 until n) {
                val w = 0.5 * (1.0 - cos(2.0 * PI * i / (n - 1)))
                real[i] = (signal[i] - mean) * w
            }
            fft(real, imag)
            for (k in 0 until numFreqBins) {
                avgPower[k] = (real[k] * real[k] + imag[k] * imag[k])
            }
            segmentsCount = 1
        } else {
            for (k in 0 until numFreqBins) {
                avgPower[k] /= segmentsCount
            }
        }

        // Evaluate pulse frequency in cardiac range [MIN_BPM, MAX_BPM]
        val minHz = MIN_BPM / 60.0
        val maxHz = min(MAX_BPM / 60.0, fps * 0.48)

        var peakIdx = -1
        var maxP = -1.0
        var totalCardiacPower = 0.0

        for (k in 0 until numFreqBins) {
            val f = freqs[k]
            if (f in minHz..maxHz) {
                val p = avgPower[k]
                totalCardiacPower += p
                if (p > maxP) {
                    maxP = p
                    peakIdx = k
                }
            }
        }

        if (peakIdx == -1 || totalCardiacPower <= 1e-12) {
            return PsdResult(freqs, avgPower, 0.0, 0.0, 0.0, 0.0)
        }

        val peakHz = freqs[peakIdx]
        val bpm = peakHz * 60.0

        // Fundamental cardiac window (+/- 0.24 Hz, capturing complete Hann main lobe 1/T = 0.222 Hz for 4.5s segment).
        // Harmonics are excluded from fundamental peak power to prevent noise inflation.
        val halfBand = CARDIAC_HALF_BAND_HZ

        var peakBandPower = 0.0
        for (k in 0 until numFreqBins) {
            val f = freqs[k]
            if (f in minHz..maxHz) {
                if (abs(f - peakHz) <= halfBand) {
                    peakBandPower += avgPower[k]
                }
            }
        }

        val peakPowerFraction = (peakBandPower / totalCardiacPower).coerceIn(0.0, 1.0)
        val noisePower = max(0.0, totalCardiacPower - peakBandPower)
        val snrDb = if (peakBandPower > 1e-12) {
            10.0 * log10(peakBandPower / max(noisePower, peakBandPower * 1e-6))
        } else {
            0.0
        }

        return PsdResult(
            frequencies = freqs,
            power = avgPower,
            peakHz = peakHz,
            bpm = bpm,
            peakPowerFraction = peakPowerFraction,
            snrDb = snrDb
        )
    }

    data class TemporalConsistencyResult(
        val isConsistent: Boolean,
        val bpmDifference: Double,
        val subBpm1: Double,
        val subBpm2: Double
    )

    /**
     * Verifies that the pulse frequency remains temporally stable across overlapping sub-windows.
     * Real physiological heartbeats stay consistent (+/- 5.5 BPM), whereas random noise or
     * transient illumination shifts produce wildly divergent peak frequencies.
     */
    fun checkTemporalConsistency(signal: DoubleArray, fps: Double): TemporalConsistencyResult {
        val n = signal.size
        val subLen = (0.70 * n).roundToInt()
        if (subLen < 32 || n < 48) {
            return TemporalConsistencyResult(false, 0.0, 0.0, 0.0)
        }

        val sub1 = DoubleArray(subLen) { signal[it] }
        val start2 = n - subLen
        val sub2 = DoubleArray(subLen) { signal[start2 + it] }

        val psd1 = estimateBpmAndQuality(sub1, fps)
        val psd2 = estimateBpmAndQuality(sub2, fps)

        val valid1 = psd1.bpm in MIN_BPM..MAX_BPM && psd1.peakPowerFraction >= 0.20
        val valid2 = psd2.bpm in MIN_BPM..MAX_BPM && psd2.peakPowerFraction >= 0.20

        if (!valid1 || !valid2) {
            return TemporalConsistencyResult(false, 999.0, psd1.bpm, psd2.bpm)
        }

        val diff = abs(psd1.bpm - psd2.bpm)
        val isConsistent = diff <= 5.5

        return TemporalConsistencyResult(isConsistent, diff, psd1.bpm, psd2.bpm)
    }

    // ---------------- FAST FOURIER TRANSFORM (RADIX-2) ----------------

    fun nextPowerOf2(value: Int): Int {
        var p = 1
        while (p < value) {
            p = p shl 1
        }
        return p
    }

    fun fft(real: DoubleArray, imag: DoubleArray) {
        val n = real.size
        if (n <= 1) return

        // Bit-reversal permutation
        var j = 0
        for (i in 0 until n) {
            if (i < j) {
                val tr = real[i]; real[i] = real[j]; real[j] = tr
                val ti = imag[i]; imag[i] = imag[j]; imag[j] = ti
            }
            var m = n shr 1
            while (m >= 1 && j >= m) {
                j -= m
                m = m shr 1
            }
            j += m
        }

        // Cooley-Tukey butterfly computations
        var len = 2
        while (len <= n) {
            val half = len shr 1
            val theta = -2.0 * PI / len
            val wStepR = cos(theta)
            val wStepI = sin(theta)

            var i = 0
            while (i < n) {
                var wR = 1.0
                var wI = 0.0
                for (k in 0 until half) {
                    val uR = real[i + k]
                    val uI = imag[i + k]
                    val vR = real[i + k + half] * wR - imag[i + k + half] * wI
                    val vI = real[i + k + half] * wI + imag[i + k + half] * wR

                    real[i + k] = uR + vR
                    imag[i + k] = uI + vI
                    real[i + k + half] = uR - vR
                    imag[i + k + half] = uI - vI

                    val nextWR = wR * wStepR - wI * wStepI
                    val nextWI = wR * wStepI + wI * wStepR
                    wR = nextWR
                    wI = nextWI
                }
                i += len
            }
            len = len shl 1
        }
    }

    fun ifft(real: DoubleArray, imag: DoubleArray) {
        val n = real.size
        // Complex conjugate
        for (i in 0 until n) {
            imag[i] = -imag[i]
        }
        fft(real, imag)
        for (i in 0 until n) {
            real[i] /= n
            imag[i] = -imag[i] / n
        }
    }

    data class PatchAnalysis(
        val regionName: String,
        val bpm: Double,
        val peakPowerFraction: Double,
        val snrDb: Double,
        val filteredSignal: DoubleArray
    )

    data class MultiPatchCoherenceResult(
        val patches: List<PatchAnalysis>,
        val consensusBpm: Double,
        val meanCoherence: Double,
        val maxFreqDiscrepancyBpm: Double,
        val isCoherent: Boolean,
        val isDeepfakeSuspect: Boolean,
        val diagnosis: String
    )

    /**
     * Computes maximum Pearson cross-correlation between two signals allowing a small
     * physiological arterial pulse transit delay (maxLag frames).
     */
    fun computeCrossCorrelation(x: DoubleArray, y: DoubleArray, maxLag: Int = 3): Double {
        val n = min(x.size, y.size)
        if (n < 8) return 0.0

        var sumX = 0.0
        var sumY = 0.0
        for (i in 0 until n) {
            sumX += x[i]
            sumY += y[i]
        }
        val meanX = sumX / n
        val meanY = sumY / n

        var varX = 0.0
        var varY = 0.0
        for (i in 0 until n) {
            val dx = x[i] - meanX
            val dy = y[i] - meanY
            varX += dx * dx
            varY += dy * dy
        }

        val denom = sqrt(varX * varY)
        if (denom < 1e-12) return 0.0

        var bestCorr = -1.0
        for (lag in -maxLag..maxLag) {
            var sumCross = 0.0
            var count = 0
            for (i in 0 until n) {
                val j = i + lag
                if (j in 0 until n) {
                    sumCross += (x[i] - meanX) * (y[j] - meanY)
                    count++
                }
            }
            if (count > n / 2) {
                val corr = sumCross / denom
                if (corr > bestCorr) {
                    bestCorr = corr
                }
            }
        }
        return bestCorr.coerceIn(-1.0, 1.0)
    }

    /**
     * Evaluates spatiotemporal multi-patch pulse coherence across anatomically separated
     * facial vascular regions (Forehead, Left Cheek, Right Cheek) based on FakeCatcher principles.
     *
     * In genuine human biology:
     * - Arterial blood enters forehead and cheeks concurrently from the common carotid tree.
     * - Blood Volume Pulse signals are synchronous with high cross-correlation and matching BPM.
     *
     * In deepfakes, diffusion videos, and face swaps:
     * - Patch signals are decoupled, have discordant frequencies, or show synthetic noise artifacts.
     */
    fun evaluateMultiPatchCoherence(
        patchMap: Map<String, List<DoubleArray>>,
        fps: Double
    ): MultiPatchCoherenceResult {
        val patchList = ArrayList<PatchAnalysis>()
        for ((name, rgb) in patchMap) {
            if (rgb.size < 16) continue
            val raw = posSignal(rgb, fps)
            val filtered = bandpassFilter(raw, fps)
            val psd = estimateBpmAndQuality(filtered, fps)
            patchList.add(PatchAnalysis(name, psd.bpm, psd.peakPowerFraction, psd.snrDb, filtered))
        }

        if (patchList.size < 2) {
            val single = patchList.firstOrNull()
            return MultiPatchCoherenceResult(
                patches = patchList,
                consensusBpm = single?.bpm ?: 0.0,
                meanCoherence = 0.0,
                maxFreqDiscrepancyBpm = 0.0,
                isCoherent = false,
                isDeepfakeSuspect = false,
                diagnosis = "Insufficient spatial patches for coherence analysis"
            )
        }

        // 1. Pairwise cross-correlations across all region pairs
        val maxLag = max(1, (0.15 * fps).roundToInt())
        val correlations = ArrayList<Double>()
        for (i in 0 until patchList.size) {
            for (j in (i + 1) until patchList.size) {
                val r = computeCrossCorrelation(patchList[i].filteredSignal, patchList[j].filteredSignal, maxLag)
                correlations.add(r)
            }
        }
        val meanCorr = if (correlations.isNotEmpty()) correlations.average() else 0.0

        // 2. Frequency discrepancy across patches with distinct peak energy
        val validPatches = patchList.filter { it.bpm in MIN_BPM..MAX_BPM && it.peakPowerFraction >= 0.22 }
        val maxFreqDiff = if (validPatches.size >= 2) {
            val bpms = validPatches.map { it.bpm }
            (bpms.maxOrNull() ?: 0.0) - (bpms.minOrNull() ?: 0.0)
        } else {
            0.0
        }

        // Consensus BPM: weighted by peak power fraction
        var weightSum = 0.0
        var bpmSum = 0.0
        for (p in patchList) {
            if (p.bpm in MIN_BPM..MAX_BPM) {
                val w = max(0.01, p.peakPowerFraction)
                bpmSum += p.bpm * w
                weightSum += w
            }
        }
        val consensusBpm = if (weightSum > 0) bpmSum / weightSum else 0.0

        // Biological coherence checks:
        val hasAdequateSnr = patchList.any { it.snrDb >= -1.0 && it.peakPowerFraction >= 0.25 }
        val hasTemporalConsistency = patchList.any { checkTemporalConsistency(it.filteredSignal, fps).isConsistent }
        val isCoherent = meanCorr >= 0.55 && maxFreqDiff <= 6.0 && validPatches.size == patchList.size && hasAdequateSnr && hasTemporalConsistency

        // Deepfake / AI Face-Swap detection:
        // A true deepfake / synthetic face presentation attack requires:
        // 1. Both patches exhibit strong, distinct periodic pulse energy (high SNR >= 1.0 dB and high peak prominence >= 0.38)
        // 2. Clear, contradictory fundamental cardiac frequencies (> 16 BPM spread) between those high-confidence signals.
        // Low-quality signals, mobile camera noise, or uneven room lighting must NEVER be misclassified as deepfakes.
        val strongPatches = patchList.filter { it.bpm in MIN_BPM..MAX_BPM && it.peakPowerFraction >= 0.38 && it.snrDb >= 1.0 }
        val strongFreqDiff = if (strongPatches.size >= 2) {
            val bpms = strongPatches.map { it.bpm }
            (bpms.maxOrNull() ?: 0.0) - (bpms.minOrNull() ?: 0.0)
        } else {
            0.0
        }
        val hasClearDiscordantBpm = (strongFreqDiff > 16.0 && strongPatches.size >= 2)
        val hasMismatchedSyntheticNoise = (meanCorr < 0.15 && patchList.size >= 2 && patchList.all { it.peakPowerFraction >= 0.40 && it.snrDb >= 2.0 })
        val isDeepfakeSuspect = (hasClearDiscordantBpm || hasMismatchedSyntheticNoise) && !isCoherent

        val diagnosis = when {
            isDeepfakeSuspect -> "Discordant spatial pulse signals detected across facial regions (mean correlation: ${String.format("%.2f", meanCorr)}, freq discrepancy: ${String.format("%.1f", strongFreqDiff)} BPM). Characteristic of deepfake/AI video synthesis."
            isCoherent -> "Synchronous multi-region pulse confirmed across facial arterial territories (mean correlation: ${String.format("%.2f", meanCorr)}, consensus BPM: ${String.format("%.1f", consensusBpm)})."
            else -> "Inconclusive spatial pulse coherence across patches (mean correlation: ${String.format("%.2f", meanCorr)})."
        }

        return MultiPatchCoherenceResult(
            patches = patchList,
            consensusBpm = consensusBpm,
            meanCoherence = meanCorr,
            maxFreqDiscrepancyBpm = if (strongPatches.size >= 2) strongFreqDiff else maxFreqDiff,
            isCoherent = isCoherent,
            isDeepfakeSuspect = isDeepfakeSuspect,
            diagnosis = diagnosis
        )
    }

    data class DisplayReplayResult(
        val isScreenReplaySuspect: Boolean,
        val riskScore: Double,
        val bgRatio: Double,
        val rgRatio: Double,
        val reason: String?
    )

    /**
     * Evaluates risk of a Screen / Display Replay Presentation Attack (phone, tablet, monitor).
     *
     * Principles:
     * 1. Cold display backlight blue emission peaks (B/G >= 1.05 inversion vs natural human skin 0.50 - 0.85).
     * 2. Unnatural color saturation outside diffuse subsurface skin reflectance (R/G >= 2.25 or <= 0.90).
     * 3. Planar surface relief lacking 3D facial depth.
     * 4. Multi-cue corroboration prevents false positives in cool ambient room lighting.
     */
    fun evaluateDisplayReplay(
        skinRgbList: List<DoubleArray>,
        peakPowerFraction: Double = 0.0,
        snrDb: Double = 0.0,
        meanDepth: Double = 0.10
    ): DisplayReplayResult {
        if (skinRgbList.size < 15) {
            return DisplayReplayResult(false, 0.0, 0.0, 0.0, null)
        }

        val avgR = skinRgbList.map { it[0] }.average()
        val avgG = skinRgbList.map { it[1] }.average()
        val avgB = skinRgbList.map { it[2] }.average()

        val rgRatio = if (avgG > 1e-4) avgR / avgG else 1.0
        val bgRatio = if (avgG > 1e-4) avgB / avgG else 1.0

        var riskScore = 0.0
        val reasons = ArrayList<String>()

        // 1. Extreme Blue Inversion (B/G >= 1.05):
        // Blue strictly and substantially exceeds green reflectance. Characteristic of strong LED display pump.
        if (bgRatio >= 1.05) {
            riskScore += 0.55
            reasons.add("Inverted Blue-to-Green ratio (B/G = ${String.format("%.2f", bgRatio)} >= 1.05), characteristic of display backlight")
        } else if (bgRatio >= 0.98 && meanDepth < 0.035) {
            // High blue shift indicates replay when corroborated by planar 2D surface relief
            riskScore += 0.55
            reasons.add("Elevated Blue-to-Green ratio (B/G = ${String.format("%.2f", bgRatio)}) with planar display surface")
        } else if (bgRatio >= 0.98) {
            // Mild blue elevation alone (e.g. cool daylight LED room lighting) is never sufficient to call spoof
            riskScore += 0.20
            reasons.add("Elevated Blue-to-Green ratio (B/G = ${String.format("%.2f", bgRatio)})")
        }

        // 2. Unnatural chrominance saturation on planar surface
        if ((rgRatio >= 2.45 || rgRatio <= 0.70) && meanDepth < 0.035) {
            riskScore += 0.35
            reasons.add("Unnatural chrominance balance (R/G = ${String.format("%.2f", rgRatio)}) on planar display")
        }

        // 3. Planar surface lacking 3D depth
        if (meanDepth < 0.030) {
            riskScore += 0.25
            reasons.add("Planar surface relief lacking 3D facial depth")
        }

        // 4. Absent pulse corroboration (requires planar surface or strong blue shift)
        if (peakPowerFraction < 0.18 && snrDb < -6.0 && (bgRatio >= 1.05 || (bgRatio >= 0.98 && meanDepth < 0.035))) {
            riskScore += 0.20
            reasons.add("Flat cardiac spectrum with elevated display cues")
        }

        val isSuspect = riskScore >= 0.55
        val reasonStr = if (reasons.isNotEmpty()) reasons.joinToString("; ") else null

        return DisplayReplayResult(isSuspect, riskScore.coerceIn(0.0, 1.0), bgRatio, rgRatio, reasonStr)
    }

}
