package com.siddhi_2305.zerotrustekyc.rppg

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.Image
import android.net.Uri
import java.io.File
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Decodes video sequentially and only converts frames needed by the analysis.
 * Random timestamp seeks through MediaMetadataRetriever repeatedly decode keyframes and
 * can take far longer than the recording itself on high-resolution phone videos.
 */
internal class VideoFrameDecoder(private val context: Context) {

    fun decode(
        videoUri: String,
        targetFps: Double,
        rotationDegrees: Int,
        onFrame: (timestampMs: Long, bitmap: Bitmap) -> Unit,
    ): Int {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null

        try {
            val uri = Uri.parse(videoUri)
            if (uri.scheme == "file" || uri.scheme == null) {
                extractor.setDataSource(File(uri.path ?: videoUri).absolutePath)
            } else {
                extractor.setDataSource(context, uri, null)
            }

            var videoTrack = -1
            var videoFormat: MediaFormat? = null
            for (track in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(track)
                if (format.getString(MediaFormat.KEY_MIME)?.startsWith("video/") == true) {
                    videoTrack = track
                    videoFormat = format
                    break
                }
            }
            require(videoTrack >= 0 && videoFormat != null) { "No video track found in recording." }

            extractor.selectTrack(videoTrack)
            val mime = videoFormat.getString(MediaFormat.KEY_MIME)
                ?: error("Video track has no MIME type.")
            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(videoFormat, null, null, 0)
            codec.start()

            val frameStepUs = (1_000_000.0 / targetFps).roundToInt().coerceAtLeast(1)
            var firstFrameUs = -1L
            var nextFrameUs = 0L
            var lastTimestampMs = -1L
            var frameCount = 0
            var inputEnded = false
            var outputEnded = false
            val bufferInfo = MediaCodec.BufferInfo()

            while (!outputEnded) {
                if (!inputEnded) {
                    val inputIndex = codec.dequeueInputBuffer(10_000)
                    if (inputIndex >= 0) {
                        val inputBuffer = codec.getInputBuffer(inputIndex)
                            ?: error("Video decoder returned an empty input buffer.")
                        inputBuffer.clear()
                        val sampleSize = extractor.readSampleData(inputBuffer, 0)
                        if (sampleSize < 0) {
                            codec.queueInputBuffer(
                                inputIndex, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM,
                            )
                            inputEnded = true
                        } else {
                            val sampleTimeUs = extractor.sampleTime.coerceAtLeast(0L)
                            codec.queueInputBuffer(
                                inputIndex,
                                0,
                                sampleSize,
                                sampleTimeUs,
                                extractor.sampleFlags,
                            )
                            extractor.advance()
                        }
                    }
                }

                when (val outputIndex = codec.dequeueOutputBuffer(bufferInfo, 10_000)) {
                    MediaCodec.INFO_TRY_AGAIN_LATER,
                    MediaCodec.INFO_OUTPUT_FORMAT_CHANGED,
                    MediaCodec.INFO_OUTPUT_BUFFERS_CHANGED -> Unit
                    else -> if (outputIndex >= 0) {
                        val endOfStream = bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                        if (bufferInfo.size > 0) {
                            val rawFrameUs = bufferInfo.presentationTimeUs.coerceAtLeast(0L)
                            if (firstFrameUs == -1L) {
                                firstFrameUs = rawFrameUs
                                nextFrameUs = rawFrameUs
                            }
                            if (rawFrameUs >= nextFrameUs) {
                                val image = codec.getOutputImage(outputIndex)
                                    ?: error("Video decoder did not provide a readable frame.")
                                try {
                                    val bitmap = image.toSmallBitmap(rotationDegrees)
                                    // Normalize presentation timestamps to start at 0ms so challenge windows match perfectly.
                                    val relativeMs = (rawFrameUs - firstFrameUs) / 1_000L
                                    val timestampMs = max(relativeMs, lastTimestampMs + 1L)
                                    onFrame(timestampMs, bitmap)
                                    lastTimestampMs = timestampMs
                                    frameCount++
                                    nextFrameUs += frameStepUs
                                    while (nextFrameUs <= rawFrameUs) nextFrameUs += frameStepUs
                                } finally {
                                    image.close()
                                }
                            }
                        }
                        codec.releaseOutputBuffer(outputIndex, false)
                        outputEnded = endOfStream
                    }
                }
            }

            return frameCount
        } finally {
            try { codec?.stop() } catch (_: Exception) { }
            try { codec?.release() } catch (_: Exception) { }
            try { extractor.release() } catch (_: Exception) { }
        }
    }

    /** Convert a sampled flexible YUV frame directly to a small RGB bitmap using high-speed array lookups. */
    private fun Image.toSmallBitmap(rotationDegrees: Int): Bitmap {
        val srcWidth = width
        val srcHeight = height
        val rotation = ((rotationDegrees % 360) + 360) % 360
        val rotatedWidth = if (rotation == 90 || rotation == 270) srcHeight else srcWidth
        val rotatedHeight = if (rotation == 90 || rotation == 270) srcWidth else srcHeight
        // 180x240 provides optimal aspect ratio and sufficient spatial resolution for MediaPipe face landmarks
        val scale = min(180.0 / rotatedWidth, 240.0 / rotatedHeight)
        val outWidth = max(1, (rotatedWidth * scale).roundToInt())
        val outHeight = max(1, (rotatedHeight * scale).roundToInt())

        val yPlane = planes[0]
        val uPlane = planes[1]
        val vPlane = planes[2]

        val yBuf = yPlane.buffer.duplicate()
        val yBytes = ByteArray(yBuf.remaining())
        yBuf.get(yBytes)

        val uBuf = uPlane.buffer.duplicate()
        val uBytes = ByteArray(uBuf.remaining())
        uBuf.get(uBytes)

        val vBuf = vPlane.buffer.duplicate()
        val vBytes = ByteArray(vBuf.remaining())
        vBuf.get(vBytes)

        val yRowStride = yPlane.rowStride
        val yPixelStride = yPlane.pixelStride
        val uRowStride = uPlane.rowStride
        val uPixelStride = uPlane.pixelStride
        val vRowStride = vPlane.rowStride
        val vPixelStride = vPlane.pixelStride

        // Precompute coordinate mappings to eliminate divisions inside the pixel loop
        val rotatedXMap = IntArray(outWidth) { outX ->
            min(rotatedWidth - 1, outX * rotatedWidth / outWidth)
        }
        val rotatedYMap = IntArray(outHeight) { outY ->
            min(rotatedHeight - 1, outY * rotatedHeight / outHeight)
        }

        val pixels = IntArray(outWidth * outHeight)

        // Hoist rotation completely out of the loops to eliminate 8+ million Pair allocations
        // and eliminate repeated conditional branching.
        when (rotation) {
            90 -> {
                for (outY in 0 until outHeight) {
                    val x = rotatedYMap[outY]
                    val rowOffset = outY * outWidth
                    for (outX in 0 until outWidth) {
                        val y = srcHeight - 1 - rotatedXMap[outX]
                        convertPixel(x, y, rowOffset + outX, pixels, yBytes, uBytes, vBytes, yRowStride, yPixelStride, uRowStride, uPixelStride, vRowStride, vPixelStride)
                    }
                }
            }
            180 -> {
                for (outY in 0 until outHeight) {
                    val y = srcHeight - 1 - rotatedYMap[outY]
                    val rowOffset = outY * outWidth
                    for (outX in 0 until outWidth) {
                        val x = srcWidth - 1 - rotatedXMap[outX]
                        convertPixel(x, y, rowOffset + outX, pixels, yBytes, uBytes, vBytes, yRowStride, yPixelStride, uRowStride, uPixelStride, vRowStride, vPixelStride)
                    }
                }
            }
            270 -> {
                for (outY in 0 until outHeight) {
                    val x = srcWidth - 1 - rotatedYMap[outY]
                    val rowOffset = outY * outWidth
                    for (outX in 0 until outWidth) {
                        val y = rotatedXMap[outX]
                        convertPixel(x, y, rowOffset + outX, pixels, yBytes, uBytes, vBytes, yRowStride, yPixelStride, uRowStride, uPixelStride, vRowStride, vPixelStride)
                    }
                }
            }
            else -> {
                for (outY in 0 until outHeight) {
                    val y = rotatedYMap[outY]
                    val rowOffset = outY * outWidth
                    for (outX in 0 until outWidth) {
                        val x = rotatedXMap[outX]
                        convertPixel(x, y, rowOffset + outX, pixels, yBytes, uBytes, vBytes, yRowStride, yPixelStride, uRowStride, uPixelStride, vRowStride, vPixelStride)
                    }
                }
            }
        }

        return Bitmap.createBitmap(pixels, outWidth, outHeight, Bitmap.Config.ARGB_8888)
    }

    @Suppress("NOTHING_TO_INLINE")
    private inline fun convertPixel(
        x: Int,
        y: Int,
        outIndex: Int,
        pixels: IntArray,
        yBytes: ByteArray,
        uBytes: ByteArray,
        vBytes: ByteArray,
        yRowStride: Int,
        yPixelStride: Int,
        uRowStride: Int,
        uPixelStride: Int,
        vRowStride: Int,
        vPixelStride: Int
    ) {
        val yOff = y * yRowStride + x * yPixelStride
        val y0 = if (yOff in yBytes.indices) yBytes[yOff].toInt() and 0xff else 0
        // Anti-aliased 2x1 spatial smoothing: averages adjacent pixel to dampen single-pixel downscaling noise
        val yOffNext = yOff + yPixelStride
        val yValue = if (yOffNext in yBytes.indices) (y0 + (yBytes[yOffNext].toInt() and 0xff)) shr 1 else y0

        val uvX = x shr 1
        val uvY = y shr 1
        val uOff = uvY * uRowStride + uvX * uPixelStride
        val vOff = uvY * vRowStride + uvX * vPixelStride

        val uValue = (if (uOff in uBytes.indices) uBytes[uOff].toInt() and 0xff else 128) - 128
        val vValue = (if (vOff in vBytes.indices) vBytes[vOff].toInt() and 0xff else 128) - 128

        val luminance = max(0, yValue - 16) * 298
        val red = ((luminance + 409 * vValue + 128) shr 8).coerceIn(0, 255)
        val green = ((luminance - 100 * uValue - 208 * vValue + 128) shr 8).coerceIn(0, 255)
        val blue = ((luminance + 516 * uValue + 128) shr 8).coerceIn(0, 255)
        pixels[outIndex] = (0xff shl 24) or (red shl 16) or (green shl 8) or blue
    }
}
